# ur5_follower.py
"""
Listens for small dx, dy, dz (meters) over UDP and nudges the UR5e TCP
accordingly using movel. Press 't' to toggle follow, 'q' to quit.

Safety:
- Commands are clamped per-step and you can add a soft workspace box.
- Ignores low-quality packets (quality < MIN_QUALITY).
"""

import os
import io
import sys
import time
import json
import socket
from contextlib import contextmanager

import URBasic

# ---------- Networking ----------
UDP_IP = "127.0.0.1"
UDP_PORT = 5005

# ---------- Robot config ----------
ROBOT_IP      = "192.168.1.100"
ACCELERATION  = 0.4
VELOCITY      = 0.2
MIN_QUALITY   = 0.05      # ignore very poor detections
MAX_STEP_M    = 0.010     # extra safety clamp

# Optional soft workspace box in base frame (set to None to disable)
SOFT_BOX = None
# Example:
# SOFT_BOX = {
#     "xmin": -0.6, "xmax": 0.6,
#     "ymin": -0.6, "ymax": 0.6,
#     "zmin":  0.05, "zmax": 0.90,
# }

# ---------- Cross-platform key reading ----------
if os.name != 'nt':
    import select
    import termios
    import tty
else:
    import msvcrt

@contextmanager
def raw_mode(fd):
    if os.name != 'nt' and fd is not None:
        orig = termios.tcgetattr(fd)
        tty.setcbreak(fd)
        try: yield
        finally: termios.tcsetattr(fd, termios.TCSADRAIN, orig)
    else:
        yield

def get_key(timeout=0.0):
    if os.name == 'nt':
        if msvcrt.kbhit():
            return msvcrt.getwch()
        time.sleep(timeout)
        return None
    else:
        dr, _, _ = select.select([sys.stdin], [], [], timeout)
        if dr:
            return sys.stdin.read(1)
        return None

def clamp(x, lo, hi):
    return max(lo, min(hi, x))

def connect_robot():
    print(f"Connecting to robot at {ROBOT_IP} …")
    model = URBasic.robotModel.RobotModel()
    robot = URBasic.urScriptExt.UrScriptExt(host=ROBOT_IP, robotModel=model)
    robot.reset_error()
    return robot

def within_box(pose):
    if SOFT_BOX is None: 
        return True
    x, y, z = pose[0], pose[1], pose[2]
    return (SOFT_BOX["xmin"] <= x <= SOFT_BOX["xmax"] and
            SOFT_BOX["ymin"] <= y <= SOFT_BOX["ymax"] and
            SOFT_BOX["zmin"] <= z <= SOFT_BOX["zmax"])

def main():
    # UDP setup
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind((UDP_IP, UDP_PORT))
    sock.settimeout(0.01)

    # Robot
    try:
        robot = connect_robot()
        print("Robot connected.")
    except Exception as e:
        print(f"Failed to connect to robot: {e}")
        return

    follow_enabled = True
    print("Follow: ON  (press 't' to toggle, 'q' to quit)")

    fd = None
    if os.name != 'nt':
        try: fd = sys.stdin.fileno()
        except (AttributeError, io.UnsupportedOperation): 
            fd = None

    last_packet = None
    with raw_mode(fd):
        try:
            while True:
                # Keyboard
                key = get_key(timeout=0.0)
                if key:
                    k = key.lower()
                    if k == 'q':
                        print("Quitting…")
                        break
                    if k == 't':
                        follow_enabled = not follow_enabled
                        print(f"Follow: {'ON' if follow_enabled else 'OFF'}")

                # UDP packet
                try:
                    data, _ = sock.recvfrom(4096)
                    pkt = json.loads(data.decode('utf-8'))
                    last_packet = pkt
                except socket.timeout:
                    pkt = None
                except Exception as e:
                    print(f"UDP parse error: {e}")
                    pkt = None

                # Act on latest packet if following is enabled
                if follow_enabled and last_packet is not None:
                    q = float(last_packet.get("quality", 0.0))
                    if q >= MIN_QUALITY:
                        dx = clamp(float(last_packet.get("dx", 0.0)), -MAX_STEP_M, +MAX_STEP_M)
                        dy = clamp(float(last_packet.get("dy", 0.0)), -MAX_STEP_M, +MAX_STEP_M)
                        dz = clamp(float(last_packet.get("dz", 0.0)), -MAX_STEP_M, +MAX_STEP_M)

                        # Build new target pose from current TCP pose
                        pose = list(robot.get_actual_tcp_pose())  # [x,y,z,rx,ry,rz]
                        new_pose = pose[:]
                        new_pose[0] += dx
                        new_pose[1] += dy
                        new_pose[2] += dz

                        if within_box(new_pose):
                            robot.movel(new_pose, a=ACCELERATION, v=VELOCITY)
                            print(f"movel: dx={dx:+.4f} dy={dy:+.4f} dz={dz:+.4f}  q={q:.2f}")
                        else:
                            print("Soft-limit: target outside workspace box; command ignored.")
                    # else: silently ignore low-quality frames

                time.sleep(0.02)  # ~50 Hz loop
        except KeyboardInterrupt:
            print("Interrupted by user.")
        finally:
            try: robot.close()
            except: pass

if __name__ == "__main__":
    main()
