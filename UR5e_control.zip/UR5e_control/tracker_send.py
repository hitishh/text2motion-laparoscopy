import cv2

def select_object_from_camera():
    cap = cv2.VideoCapture(0)  # Change index if needed for your camera
    if not cap.isOpened():
        print("Could not open camera.")
        return None
    
    print("Press SPACE to capture the frame for object selection.")
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        cv2.imshow("Camera Feed - Press SPACE to capture", frame)
        key = cv2.waitKey(1) & 0xFF
        if key == 32:  # Spacebar
            break
        elif key == 27:  # ESC to quit
            cap.release()
            cv2.destroyAllWindows()
            return None

    cap.release()
    
    # Let user select ROI
    roi = cv2.selectROI("Select Object", frame, fromCenter=False, showCrosshair=True)
    cv2.destroyAllWindows()
    
    if roi == (0, 0, 0, 0):
        print("No object selected.")
        return None
    
    x, y, w, h = roi
    selected_region = frame[y:y+h, x:x+w]
    
    # Optional: save or process for tracking later
    cv2.imshow("Selected Object", selected_region)
    cv2.waitKey(500)
    cv2.destroyAllWindows()
    
    return roi, frame

# Example usage
roi_data = select_object_from_camera()
if roi_data:
    roi, frame = roi_data
    print("ROI coordinates:", roi)
