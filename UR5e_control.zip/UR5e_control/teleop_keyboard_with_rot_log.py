import time, sys, os, io, json, pathlib
from contextlib import contextmanager
import numpy as np
import URBasic
from URBasic.kinematic import Forwardkin_manip  # (left as-is from your script)
# Optional: math3d is not required now
# import math3d as m3d

# ---------- Configuration ----------
ROBOT_IP = "172.22.237.174"
ACCELERATION = 0.4
VELOCITY = 0.2
STEP_SIZE = 0.01       # [m]
STEP_ROT  = 0.01       # [rad]
DATA_PATH = pathlib.Path("data/real_pairs.jsonl")
TBP_PATH  = pathlib.Path("TbP.npy")   # patient {P} in base {B}; saved from calibration

SAFE_MIN_STANDOFF_M = 0.03
SAFE_MAX_STANDOFF_M = 0.35

# --------- cross-platform console raw mode ----------
if os.name != 'nt':
    import select, termios, tty  # POSIX only
else:
    import msvcrt  # Windows only

@contextmanager
def raw_mode(fileobj):
    if os.name != 'nt' and fileobj is not None:
        orig_attrs = termios.tcgetattr(fileobj)
        tty.setcbreak(fileobj)
        try:
            yield
        finally:
            termios.tcsetattr(fileobj, termios.TCSADRAIN, orig_attrs)
    else:
        yield

def get_key(timeout=0.0):
    if os.name == 'nt':
        if msvcrt.kbhit():
            return msvcrt.getwch()
        time.sleep(timeout)
        return None
    else:
        dr, _, _ = select.select([sys.stdin], [], [], timeout)
        if dr: return sys.stdin.read(1)
        return None

# --------- math helpers ----------
def axis_angle_to_R(rx, ry, rz):
    a = float(np.linalg.norm([rx, ry, rz]))
    if a < 1e-9: return np.eye(3)
    ux, uy, uz = rx/a, ry/a, rz/a
    c, s = np.cos(a), np.sin(a); C = 1.0 - c
    return np.array([
        [c+ux*ux*C,     ux*uy*C - uz*s, ux*uz*C + uy*s],
        [uy*ux*C + uz*s, c+uy*uy*C,     uy*uz*C - ux*s],
        [uz*ux*C - uy*s, uz*uy*C + ux*s, c+uz*uz*C    ]
    ])

def standoff_mm_from_pose(pose, TbP):
    """Positive into the patient (consistent with our controller)."""
    pivot_b = TbP[:3,3]
    R = axis_angle_to_R(pose[3], pose[4], pose[5])
    z = R[:,2]
    return -float(np.dot(np.array(pose[:3]) - pivot_b, z))*1000.0

# --------- robot connect ----------
def connect_robot():
    print(f"Connecting to robot at {ROBOT_IP} …")
    model = URBasic.robotModel.RobotModel()
    robot = URBasic.urScriptExt.UrScriptExt(host=ROBOT_IP, robotModel=model)
    robot.reset_error()
    return robot

def teleop_loop(robot, TbP):
    print("\nTeleoperation started.")
    print("Translate:  A/D (X), W/S (Y), R/F (Z)")
    print("Rotate:     J/L (Rx), I/K (Ry), U/O (Rz)")
    print("Capture:    C  (record a labeled training sample)")
    print("Q to quit.")

    fd = None
    if os.name != 'nt':
        try:
            fd = sys.stdin.fileno()
        except (AttributeError, io.UnsupportedOperation):
            fd = None

    DATA_PATH.parent.mkdir(parents=True, exist_ok=True)

    with raw_mode(fd):
        while True:
            movement = input("Enter command: ").strip().lower()
            if movement == 'q':
                print("Exiting teleoperation loop…")
                break

            # ---- capture a labeled focus sample ----
            if movement == 'c':
                pose = list(map(float, robot.get_actual_tcp_pose()))
                s_mm = standoff_mm_from_pose(pose, TbP)
                print(f"Current TCP pose  [x y z rx ry rz]: {[round(p,5) for p in pose]}")
                print(f"Current standoff: {s_mm:.1f} mm")

                # 1) free-text instruction
                instruction = input("Instruction text (e.g., 'focus on x=25, y=-10, z=70, standoff=120, roll=0'):\n> ").strip()
                if not instruction:
                    print("Instruction is required to train the LLM. Skipping capture.")
                    continue

                # 2) target JSON fields (point in patient frame)
                def _ask_float(prompt, default=None):
                    s = input(f"{prompt}{'' if default is None else f' [{default}]'}: ").strip()
                    if s == "" and default is not None: return float(default)
                    return float(s)

                print("\nEnter target point in patient frame {P} (mm).")
                x_mm = _ask_float("x_mm")
                y_mm = _ask_float("y_mm")
                z_mm = _ask_float("z_mm")
                st_mm = _ask_float("standoff_mm", default=round(max(SAFE_MIN_STANDOFF_M*1000, min(s_mm, SAFE_MAX_STANDOFF_M*1000))))
                roll_deg = _ask_float("roll_deg", default=0.0)

                # safety clamp standoff
                st_mm = float(np.clip(st_mm, SAFE_MIN_STANDOFF_M*1000.0, SAFE_MAX_STANDOFF_M*1000.0))

                target = {
                    "action":"focus",
                    "point_mm":[x_mm, y_mm, z_mm],
                    "standoff_mm": st_mm,
                    "roll_deg": roll_deg
                }
                rec = {
                    "ts": time.time(),
                    "instruction": instruction,
                    "target": target,
                    "context": {
                        "pose_tcp": pose,                      # [x,y,z, rx,ry,rz]
                        "standoff_mm": s_mm,
                        "TbP_rowmajor": TbP.reshape(-1).tolist()
                    }
                }
                with DATA_PATH.open("a", encoding="utf-8") as f:
                    f.write(json.dumps(rec) + "\n")
                print(f"Saved sample → {DATA_PATH.resolve()}")
                continue

            # ---- jogging ----
            pose = list(map(float, robot.get_actual_tcp_pose()))
            moved = False

            # Translation
            if   movement == 'a': pose[0] -= STEP_SIZE; moved = True
            elif movement == 'd': pose[0] += STEP_SIZE; moved = True
            elif movement == 'w': pose[1] += STEP_SIZE; moved = True
            elif movement == 's': pose[1] -= STEP_SIZE; moved = True
            elif movement == 'r': pose[2] += STEP_SIZE; moved = True
            elif movement == 'f': pose[2] -= STEP_SIZE; moved = True

            # Rotation
            elif movement == 'j': pose[3] -= STEP_ROT; moved = True
            elif movement == 'l': pose[3] += STEP_ROT; moved = True
            elif movement == 'i': pose[4] += STEP_ROT; moved = True
            elif movement == 'k': pose[4] -= STEP_ROT; moved = True
            elif movement == 'u': pose[5] += STEP_ROT; moved = True
            elif movement == 'o': pose[5] -= STEP_ROT; moved = True

            if moved:
                try:
                    robot.movel(pose, a=ACCELERATION, v=VELOCITY)
                    # (Optional) quick printouts
                    cur_joints = list(robot.get_actual_joint_positions())
                    fk_position = Forwardkin_manip(cur_joints, rob='ur5')
                    print("TCP Pose:", [round(float(x), 4) for x in pose])
                    print("TCP Position (FK):", [round(float(x), 4) for x in fk_position])
                except Exception as e:
                    print(f"Movement failed: {e}")
                    break

def main():
    # Load TbP (patient frame) or fall back to identity
    if TBP_PATH.exists():
        TbP = np.load(TBP_PATH)
        print("Loaded TbP.npy")
    else:
        TbP = np.eye(4)
        print("WARNING: TbP.npy not found. Using identity (patient frame = base frame).")

    try:
        robot = connect_robot()
        init_j = list(robot.get_actual_joint_positions())
        fk_position = Forwardkin_manip(init_j, rob='ur5')
        print("Initial TCP Position (FK):", [round(float(x),4) for x in fk_position])
        teleop_loop(robot, TbP)
    except Exception as e:
        print(f"Failed: {e}")
    finally:
        try:
            robot.close()
        except Exception:
            pass

if __name__ == '__main__':
    main()
