"""
Teleoperation script for UR5e robot using keyboard input.

This script attempts to connect to a UR5‑series robot using the URBasic
library shipped with this project.  Once connected it performs a small
sanity movement on joint 0 to ensure the connection is healthy.  After
that the script enters a control loop where you can jog the tool
position using simple key presses.  Each key press nudges the tool in
0.01 m increments along the X, Y or Z axes.  The robot is driven using
the built‑in `movel` command so that inverse kinematics are handled by
the controller itself.

Controls
========

The script uses single letter commands rather than arrow keys so it
remains portable across different terminals and platforms:

  • **A/D** – move along the X axis (A = negative, D = positive)
  • **W/S** – move along the Y axis (W = positive, S = negative)
  • **R/F** – move along the Z axis (R = positive, F = negative)
  • **Q**   – quit the program

You can hold a key down for continuous motion.  Positions are read
continuously from the robot so there is no hardcoded zero point – the
robot will continue from wherever it currently is.  Speed and
acceleration can be tuned via the `VELOCITY` and `ACCELERATION`
constants.

If you wish to run this script on a machine without a connected robot
you may comment out the connection lines and mock the `robot` object
with your own implementation.  The script only requires `get_actual_tcp_pose` and
`movel` methods on the robot object to function.
"""

import time
import sys
from contextlib import contextmanager
import os
import io
import math3d as m3d
import URBasic
from URBasic.kinematic import Invkine_manip, Forwardkin_manip

"""The termios, tty and select modules are only available on POSIX systems.
On Windows we will instead use msvcrt for key detection.  The imports
are therefore deferred based on the operating system to prevent
ImportError on Windows."""
if os.name != 'nt':
    import select  # POSIX only
    import termios
    import tty
else:
    import msvcrt  # Windows only


# ---------- Configuration ----------
# Adjust these values to suit your setup.
ROBOT_IP = "192.168.1.100"  # IP address of the UR5e controller
ACCELERATION = 0.4           # Tool acceleration [m/s²]
VELOCITY = 0.2               # Tool velocity [m/s]
STEP_SIZE = 0.01             # Position step for each key press [m]


@contextmanager
def raw_mode(fileobj):
    """Context manager that puts the terminal into raw mode when possible.

    On POSIX systems the terminal settings are adjusted so that
    individual key presses can be read without waiting for a newline.
    On Windows no modifications are required because key reading is
    handled through the `msvcrt` module.  The argument `fileobj` is
    ignored on Windows.
    """
    # Use raw mode only on POSIX systems when a valid file descriptor
    # is provided.  Windows uses msvcrt for key reading so there is
    # nothing to configure here.  When fileobj is None the context
    # manager yields immediately.
    if os.name != 'nt' and fileobj is not None:
        # Save the current terminal settings and switch to cbreak mode.
        orig_attrs = termios.tcgetattr(fileobj)
        tty.setcbreak(fileobj)
        try:
            yield
        finally:
            termios.tcsetattr(fileobj, termios.TCSADRAIN, orig_attrs)
    else:
        # On Windows or when no file object provided, just yield.
        yield


def get_key(timeout=0.0):
    """Cross‑platform non‑blocking key press reader.

    When running on POSIX the function uses `select` and `sys.stdin` to
    poll for a single character without waiting for a newline.
    On Windows it uses the `msvcrt` module to detect and read key
    presses.  The optional `timeout` parameter is respected on POSIX,
    but ignored on Windows.

    Returns
    -------
    str | None
        The character pressed or `None` if no key press was detected.
    """
    if os.name == 'nt':
        # On Windows use msvcrt.kbhit() to test for a key press.  If
        # available read a Unicode character using getwch(), which
        # returns a string.  Otherwise return None.
        if msvcrt.kbhit():
            return msvcrt.getwch()
        else:
            # Sleep briefly to avoid busy waiting; timeout ignored
            time.sleep(timeout)
            return None
    else:
        dr, dw, de = select.select([sys.stdin], [], [], timeout)
        if dr:
            return sys.stdin.read(1)
        return None


def connect_robot():
    """Attempt to connect to the UR5e and return a handle.

    The URBasic library provides a high level wrapper around the
    various UR interfaces (RTDE, dashboard and real‑time client).
    Here we instantiate a `RobotModel` which holds kinematic
    information for the UR5e and then create a `UrScriptExt` object
    pointing at the controller.  If the connection fails an
    exception will propagate which callers may handle.
    """
    print("Connecting to robot at {} …".format(ROBOT_IP))
    # Build the internal kinematic model.  This is required by the
    # UrScriptExt constructor.
    model = URBasic.robotModel.RobotModel()
    robot = URBasic.urScriptExt.UrScriptExt(host=ROBOT_IP, robotModel=model)
    # Ensure any safety or protective stops are cleared and the
    # robot is ready for commands.
    robot.reset_error()
    return robot


def sanity_move(robot):
    """Perform a small joint movement as a connection sanity check.

    Query the current joint positions, move joint 0 by ±5° and then
    return it to its original position.  Any exception raised here
    usually indicates a connection or permission problem.
    """
    print("Performing sanity check on joint 0…")
    
    # Fetch the current joint positions first
    current_joints = list(robot.get_actual_joint_positions())
    print("Current joint angles [rad]: {}".format([
        round(float(j), 4) for j in current_joints  # Show joint angles in radians (rounded to 4 decimal places)
    ]))
    
    # Move joint 0 +5°
    joints_plus = current_joints.copy()
    joints_plus[0] += 5.0 * 3.141592653589793 / 180.0
    robot.movej(q=joints_plus, a=ACCELERATION, v=VELOCITY)
    time.sleep(1.0)
    
    # Move joint 0 –5°
    joints_minus = current_joints.copy()
    joints_minus[0] -= 5.0 * 3.141592653589793 / 180.0
    robot.movej(q=joints_minus, a=ACCELERATION, v=VELOCITY)
    time.sleep(1.0)
    print("Sanity check complete.")
    
    current_joints = list(robot.get_actual_joint_positions())
    # Convert joint angles from radians to degrees for display
    print("Current joint angles [rad]: {}".format([
        round(float(j), 4) for j in current_joints
    ]))
    
def teleop_loop(robot):
    """Main teleoperation loop.

    Continuously read characters from the keyboard and nudge the tool
    position accordingly.  Each iteration queries the current TCP
    pose, calculates a new target pose based on the key pressed and
    then commands the robot to move along a straight line to that
    pose using `movel`.  If no key is pressed the loop sleeps
    briefly to yield CPU time.
    """
    print("\nTeleoperation started. Use A/D (X-axis), W/S (Y-axis), R/F (Z-axis) to jog the tool; Q to quit.")
    # When running on POSIX pass the file descriptor for stdin to enable
    # raw mode.  On Windows pass None so that raw_mode simply yields.
    fd = None
    if os.name != 'nt':
        # Some environments (e.g. IDLE) do not support fileno; guard
        # against AttributeError to avoid exceptions.
        try:
            fd = sys.stdin.fileno()
        except (AttributeError, io.UnsupportedOperation):
            fd = None
    with raw_mode(fd):
        while True:
            #Ask for user input
            movement = input("Enter movement command (A/D, W/S, R/F) or Q to quit: ").lower()
            # Non‑blocking read of a single key
            ch = get_key(timeout=0.05)
            # If no key press was detected just continue looping
            '''if ch is None:
                continue
            # Normalize to uppercase for simplicity
            key = ch.lower()
            # If the user hit Ctrl‑C or Ctrl‑D just break out
            if ch in ('\x03', '\x04'):
                break
                '''
            if movement == 'q':
                print("Exiting teleoperation loop…")
                break
            # Fetch the current pose (x, y, z, rx, ry, rz)
            pose = list(robot.get_actual_tcp_pose())
            
            moved = False
            if movement == 'a':  # −X
                pose[0] -= STEP_SIZE   
                moved = True
            elif movement == 'd':  # +X
                pose[0] += STEP_SIZE
                moved = True
            elif movement == 'w':  # +Y
                pose[1] += STEP_SIZE
                moved = True
            elif movement == 's':  # −Y
                pose[1] -= STEP_SIZE
                moved = True
            elif movement == 'r':  # +Z
                pose[2] += STEP_SIZE
                moved = True
            elif movement == 'f':  # −Z
                pose[2] -= STEP_SIZE
                moved = True
            '''
            if key == 'a':  # −X
                pose[0] -= STEP_SIZE
                moved = True
            elif key == 'd':  # +X
                pose[0] += STEP_SIZE
                moved = True
            elif key == 's':  # −Y
                pose[1] -= STEP_SIZE
                moved = True
            elif key == 'w':  # +Y
                pose[1] += STEP_SIZE
                moved = True
            elif key == 'f':  # −Z
                pose[2] -= STEP_SIZE
                moved = True
            elif key == 'r':  # +Z
                pose[2] += STEP_SIZE
                moved = True
            # Only command the robot if a motion key was pressed
            '''
            if moved:
                try:
                    #sending movement command
                    robot.movel(pose, a=ACCELERATION, v=VELOCITY)
                    # **Forward Kinematics Result (TCP Position)**
                    current_joints = list(robot.get_actual_joint_positions())
                    fk_position = Forwardkin_manip(current_joints, rob='ur5')  # Use the correct robot model
                    print(f"Current TCP Position (FK): {fk_position}")
                    '''current_tcp_position = robot.get_actual_tcp_pose()
                    print(f"Current TCP Position (FK): {current_tcp_position}")
                    # **Inverse Kinematics Result (Joint Angles)**
                    desired_pos = m3d.Transform(pose)
                    new_joint_angles = Invkine_manip(desired_pos, list(robot.get_actual_joint_positions(), rob='ur5'))
                    # Display the calculated joint angles (IK result)
                    print(f"Calculated Joint Angles (IK): {new_joint_angles}")
                    '''
                except Exception as e:
                    # Log the exception and break the loop so that the robot
                    # connection can be closed cleanly in the caller.
                    print(f"Movement failed: {e}")
                    break


def main():
    """Entry point when this module is executed as a script."""
    try:
        robot = connect_robot()
        # Fetch the initial joint positions
        initial_joints = list(robot.get_actual_joint_positions())
        fk_position = Forwardkin_manip(initial_joints, rob='ur5')  # Use the correct robot model ('ur5' or 'ur10')
        print("Initial TCP Position (FK):", fk_position)
    except Exception as e:
        print("Failed to connect to robot: {}".format(e))
        return
    try:
        sanity_move(robot)
        # Fetch the current joint positions after sanity check
        current_joints = list(robot.get_actual_joint_positions())
        fk_position = Forwardkin_manip(current_joints, rob='ur5')  # Use the correct robot model ('ur5' or 'ur10')
        print("TCP Position (FK) After Sanity Check:", fk_position)
    except Exception as e:
        print("Sanity check failed: {}".format(e))
        robot.close()
        return
    try:
        teleop_loop(robot)
    except KeyboardInterrupt:
        print("Interrupted by user.")
    finally:
        # Always attempt to close the connection cleanly
        robot.close()


if __name__ == '__main__':
    main()
