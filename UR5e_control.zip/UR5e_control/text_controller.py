import math, numpy as np, URBasic
from rcm_kin import look_at_pose, zoom_pose, tilt_pose, standoff_mm, solve_ik_if_available
from URBasic.kinematic import Forwardkin_manip  # debug FK, like your teleop script :contentReference[oaicite:3]{index=3}

ROBOT_IP = "192.168.1.102"   # set yours
ACC, VEL = 0.4, 0.2
SAFE_MAX_TILT_DEG = 35
SAFE_MIN_STANDOFF_M = 0.03
SAFE_MAX_STANDOFF_M = 0.35
USE_IK = False  # set True to drive with movej via your UR5eKinematics; else movel

def parse(text):
    import re
    s = text.strip().lower()
    m = re.search(r'x\s*=\s*([-+]?\d*\.?\d+).*[, ]y\s*=\s*([-+]?\d*\.?\d+).*[, ]z\s*=\s*([-+]?\d*\.?\d+)', s)
    if s.startswith("focus") and m:
        x,y,z = map(float, m.groups())
        st = 60.0; ro = 0.0
        m2 = re.search(r'standoff\s*=\s*([-+]?\d*\.?\d+)', s);  st = float(m2.group(1)) if m2 else st
        m3 = re.search(r'roll\s*=\s*([-+]?\d*\.?\d+)', s);      ro = float(m3.group(1)) if m3 else ro
        return ("focus", x,y,z, ro, st)
    if s.startswith("zoom"):
        m = re.search(r'zoom\s+(in|out)\s*([-+]?\d*\.?\d+)?', s)
        if m:
            sign = +1.0 if m.group(1)=="in" else -1.0
            d = float(m.group(2) or 10.0)
            return ("zoom", sign*abs(d))
    if s.startswith("pan"):
        m = re.search(r'pan\s+(left|right|up|down)\s*([-+]?\d*\.?\d+)?', s)
        if m:
            where = m.group(1); deg = float(m.group(2) or 2.0)
            return ("pan", where, deg)
    if s in ("hold","stop"):
        return ("hold",)
    return None

class Controller:
    def __init__(self, robot_ip):
        model = URBasic.robotModel.RobotModel()
        self.robot = URBasic.urScriptExt.UrScriptExt(host=robot_ip, robotModel=model)
        self.robot.reset_error()
        # tip TCP (identity)
        self.robot.set_tcp([0,0,0,0,0,0])
        self.TbP = np.load("TbP.npy")
        print("Loaded TbP.npy")

    def close(self):
        try: self.robot.close()
        except: pass

    def get_pose(self):  # [x,y,z, rx,ry,rz]
        return list(map(float, self.robot.get_actual_tcp_pose()))

    def _exec_pose(self, target_pose):
        print("GO:", [round(float(p),5) for p in target_pose])
        if USE_IK:
            # Try your UR5eKinematics IK first; fall back to movel if unavailable
            q_now = list(map(float, self.robot.get_actual_joint_positions()))
            q = solve_ik_if_available(target_pose, q_now)
            if q:
                self.robot.movej(q=q, a=ACC, v=VEL)
                return
        self.robot.movel(target_pose, a=ACC, v=VEL)

    def focus(self, x_mm, y_mm, z_mm, roll_deg=0.0, standoff_mm=250.0):
        pivot_b = self.TbP[:3,3]
        pose = look_at_pose(self.TbP, pivot_b, [x_mm,y_mm,z_mm], roll_deg, standoff_mm,
                            SAFE_MIN_STANDOFF_M, SAFE_MAX_STANDOFF_M)
        self._exec_pose(pose)

    def zoom(self, delta_mm):
        pose = zoom_pose(self.get_pose(), self.TbP, delta_mm,
                         SAFE_MIN_STANDOFF_M, SAFE_MAX_STANDOFF_M)
        self._exec_pose(pose)

    def tilt(self, d_rx_deg=0.0, d_ry_deg=0.0):
        pose = tilt_pose(self.get_pose(), self.TbP, d_rx_deg, d_ry_deg, SAFE_MAX_TILT_DEG)
        self._exec_pose(pose)

if __name__ == "__main__":
    ctrl = Controller(ROBOT_IP)
    try:
        print("Type commands like:")
        print("  focus on x=30, y=-10, z=40, standoff=70")
        print("  zoom in 15    |  zoom out 10")
        print("  pan left 3    |  pan up 2    |  hold")
        while True:
            s = input("\nInstruction (q to quit): ").strip()
            if s.lower() in ("q","quit","exit"): break
            cmd = parse(s)
            if not cmd:
                print("Could not parse.")
                continue

            pre = ctrl.get_pose()
            if cmd[0]=="focus":
                _,x,y,z,ro,st = cmd; ctrl.focus(x,y,z, ro, st)
            elif cmd[0]=="zoom":
                _,d = cmd;          ctrl.zoom(d)
            elif cmd[0]=="pan":
                _,where,deg = cmd
                if   where=="left":  ctrl.tilt(d_rx_deg=-deg)
                elif where=="right": ctrl.tilt(d_rx_deg=+deg)
                elif where=="up":    ctrl.tilt(d_ry_deg=+deg)
                elif where=="down":  ctrl.tilt(d_ry_deg=-deg)
            elif cmd[0]=="hold":
                print("Holding.")

            post = ctrl.get_pose()
            # Optional FK debug like your teleop script:
            try:
                q = list(ctrl.robot.get_actual_joint_positions())
                fk = Forwardkin_manip(q, rob='ur5')  # requires URBasic.kinematic
                print("FK TCP:", [round(float(v),4) for v in fk])
            except Exception:
                pass
    finally:
        ctrl.close()
