import json, random, math, pathlib

SAFE_MAX_TILT_DEG = 35
SAFE_MIN_S = 30
SAFE_MAX_S = 350

def within_cone(x,y,z, max_deg=SAFE_MAX_TILT_DEG):
    # {P}: +Z is into the patient. Limit angle to +Z
    v = (float(x), float(y), float(z))
    n = math.sqrt(x*x + y*y + z*z) + 1e-9
    cosang = z / n
    ang = math.degrees(math.acos(max(-1.0, min(1.0, cosang))))
    return ang <= max_deg

def sample_focus():
    # sample until in cone
    for _ in range(1000):
        x = random.randint(-60, 60)
        y = random.randint(-40, 40)
        z = random.randint(  0, 90)
        if within_cone(x,y,z): break
    st = random.choice([40,60,80,120,180,250,300])
    ro = random.choice([0,0,0,5,-5,10,-10])
    txt = f"focus on x={x}, y={y}, z={z}, standoff={st}, roll={ro}"
    tgt = {"action":"focus","point_mm":[x,y,z],"standoff_mm":st,"roll_deg":ro}
    return {"instruction": txt, "target": tgt}

def sample_zoom():
    d = random.choice([5,10,12,15,20,25,30])
    txt = random.choice([f"zoom in {d}", f"zoom out {d}"])
    tgt = {"action":"zoom","delta_mm": (d if "in" in txt else -d)}
    return {"instruction": txt, "target": tgt}

def sample_pan():
    dir = random.choice(["left","right","up","down"])
    deg = random.choice([1,2,3,4,5,8,10])
    txt = f"pan {dir} {deg}"
    d_rx = d_ry = 0
    if   dir=="left":  d_rx=-deg
    elif dir=="right": d_rx=+deg
    elif dir=="up":    d_ry=+deg
    elif dir=="down":  d_ry=-deg
    tgt = {"action":"tilt","d_rx_deg":d_rx,"d_ry_deg":d_ry}
    return {"instruction": txt, "target": tgt}

def sample_negative():
    bad = random.choice([
        "move x 50", "translate y -30", "roll 90", "zoom in 500", "pan left 90"
    ])
    # teach clamping/holding:
    mapping = {
        "move x 50": {"action":"hold"},
        "translate y -30": {"action":"hold"},
        "roll 90": {"action":"focus","point_mm":[0,0,60],"standoff_mm":60,"roll_deg":15},
        "zoom in 500": {"action":"focus","point_mm":[0,0,60],"standoff_mm":SAFE_MIN_S,"roll_deg":0},
        "pan left 90": {"action":"tilt","d_rx_deg":-SAFE_MAX_TILT_DEG,"d_ry_deg":0},
    }
    return {"instruction": bad, "target": mapping[bad]}

def main(n=5000, path="data/synth.jsonl"):
    pathlib.Path("data").mkdir(exist_ok=True)
    with open(path,"w",encoding="utf-8") as f:
        for _ in range(n):
            kind = random.choices(
                ["focus","pan","zoom","neg"], weights=[0.4,0.3,0.25,0.05], k=1
            )[0]
            rec = (sample_focus() if kind=="focus" else
                   sample_pan()   if kind=="pan"   else
                   sample_zoom()  if kind=="zoom"  else
                   sample_negative())
            f.write(json.dumps(rec)+"\n")

if __name__=="__main__":
    main()
