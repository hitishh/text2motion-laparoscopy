# make_dataset.py
import json, math

IN_PATH  = "llm_charuco_ur5e_aug_600.jsonl"
OUT_PATH = "llm_urbasic_code_sft.jsonl"

ACCELERATION = 0.4
VELOCITY     = 0.2
ROBOT_IP     = "192.168.1.100"   # set yours

def mk_abs_movel_snippet(pose):
    # pose is [x,y,z,rx,ry,rz]
    code = f"""import URBasic
ACCELERATION={ACCELERATION}; VELOCITY={VELOCITY}
pose={[round(float(x),5) for x in pose]}
model=URBasic.robotModel.RobotModel()
robot=URBasic.urScriptExt.UrScriptExt(host='{ROBOT_IP}', robotModel=model)
try:
    robot.reset_error()
    robot.movel(pose, a=ACCELERATION, v=VELOCITY)
finally:
    robot.close()
"""
    return code

seen = set()
with open(IN_PATH) as fin, open(OUT_PATH,"w") as fout:
    for line in fin:
        row = json.loads(line)
        instr = row["instruction"].strip()
        pose  = row["tcp_pose"]  # prefer TCP over joints for movel
        # de-dup on (instruction, rounded pose)
        key = (instr, tuple(round(float(x),4) for x in pose))
        if key in seen: 
            continue
        seen.add(key)
        out = {
            "instruction": instr,
            "tags": ["abs_move","movel","charuco"],
            "output_code": mk_abs_movel_snippet(pose)
        }
        fout.write(json.dumps(out, ensure_ascii=False) + "\n")
print("Wrote", OUT_PATH, "examples:", len(seen))
