# teleop_with_center_cell_import.py
# Library-style teleop: export connect_robot(ip) and run_teleop(robot, tracker, on_record).
# - Movement keys only
# - Press 'x' to trigger on_record() (caller handles logging)
# - Press 'q' to end teleop loop (camera feed remains running if tracker is still active)

import URBasic
from URBasic.kinematic import Forwardkin_manip  # optional; for prints

# ---- Motion config ----
ACCELERATION = 0.4     # [m/s^2]
VELOCITY     = 0.2     # [m/s]
STEP_XYZ     = 0.005   # [m]
STEP_ROT     = 0.02   # [rad] ~1°

def connect_robot(ip: str):
    print(f"Connecting to robot at {ip} …")
    model = URBasic.robotModel.RobotModel()
    robot = URBasic.urScriptExt.UrScriptExt(host=ip, robotModel=model)
    robot.reset_error()
    print("Connected.")
    return robot

def run_teleop(robot, tracker, on_record):
    """
    robot: URBasic.urScriptExt.UrScriptExt
    tracker: CenterCellTracker (from charuco_center_cell.py), already started
    on_record: callable() -> None  (called when user presses 'x')
    """
    print("\nTeleoperation started.")
    print("Move TCP:")
    print("  Translation: A/D (±X), W/S (±Y), R/F (±Z)")
    print("  Rotation:    J/L (±Rx), I/K (±Ry), U/O (±Rz)")
    print("Record sample: X")
    print("Quit teleop:   Q\n")

    try:
        while True:
            cmd = input("Command [a/d/w/s/r/f/j/l/i/k/u/o | x=record | q=quit]: ").strip().lower()
            if cmd == "q":
                break

            if cmd == "x":
                try:
                    on_record()
                except Exception as e:
                    print(f"[record] error: {e}")
                continue

            pose = list(robot.get_actual_tcp_pose())
            moved = False

            # Translation
            if   cmd == 'a': pose[0] -= STEP_XYZ; moved = True
            elif cmd == 'd': pose[0] += STEP_XYZ; moved = True
            elif cmd == 'w': pose[1] += STEP_XYZ; moved = True
            elif cmd == 's': pose[1] -= STEP_XYZ; moved = True
            elif cmd == 'r': pose[2] += STEP_XYZ; moved = True
            elif cmd == 'f': pose[2] -= STEP_XYZ; moved = True

            # Rotation
            elif cmd == 'j': pose[3] -= STEP_ROT; moved = True
            elif cmd == 'l': pose[3] += STEP_ROT; moved = True
            elif cmd == 'i': pose[4] += STEP_ROT; moved = True
            elif cmd == 'k': pose[4] -= STEP_ROT; moved = True
            elif cmd == 'u': pose[5] += STEP_ROT; moved = True
            elif cmd == 'o': pose[5] -= STEP_ROT; moved = True

            if moved:
                try:
                    robot.movel(pose, a=ACCELERATION, v=VELOCITY)
                    # Optional brief status (comment out if you want silence)
                    # j = list(robot.get_actual_joint_positions())
                    # fk = Forwardkin_manip(j, rob='ur5')
                    # print("TCP Pose:", [round(float(x), 4) for x in pose])
                    # print("FK Pos:  ", [round(float(x), 4) for x in fk])
                except Exception as e:
                    print("Movement failed:", e)
    except KeyboardInterrupt:
        pass
