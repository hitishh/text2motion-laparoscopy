# collect_llm_instructions.py
# Orchestrates everything:
# - starts CenterCellTracker (charuco_center_cell.py)
# - connects to robot
# - calls teleop.run_teleop(robot, tracker, on_record)
# - on_record() prompts for instruction and saves:
#   {instruction, tcp_pose, joint_angles, target_cell}
# Camera feed remains ON until you press ESC in the window.

import os
import json
import time

from charuco_center_cell import CenterCellTracker       # camera + cell identification
import teleop_with_center_cell_import as teleop         # robot teleop (modified module)

OUTPUT_PATH  = os.path.join(os.path.dirname(__file__), "llm_charuco_ur5e.jsonl")
CAM_INDEX    = 0

def append_example(path: str, example: dict):
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(example, ensure_ascii=False) + "\n")

def main():
    robot_ip = input("Enter UR5e IP (e.g., 192.168.1.100): ").strip()
    if not robot_ip:
        print("No IP provided."); return

    # 1) Start the tracker (window stays ON; press ESC to close at the end)
    tracker = CenterCellTracker(cam_index=CAM_INDEX, visualize=True, verbose=False)
    tracker.start()

    # 2) Connect the robot
    try:
        robot = teleop.connect_robot(robot_ip)
    except Exception as e:
        print(f"Robot connection failed: {e}")
        print("You can still watch the camera feed; press ESC in the feed window to exit.")
        tracker.join()
        return

    print("\nReady. Use teleop keys to move; press X to record an example.")

    # 3) Define what happens on 'x' (record)
    def on_record():
        instruction = input("Instruction: ").strip()
        target_cell = tracker.get_latest_cell()
        if target_cell is None:
            print("No live cell detected; saving target_cell='UNKNOWN'.")
            target_cell = "UNKNOWN"
        try:
            tcp_pose     = [float(x) for x in list(robot.get_actual_tcp_pose())]
            joint_angles = [float(q) for q in list(robot.get_actual_joint_positions())]
        except Exception as e:
            print(f"Pose read failed: {e}")
            tcp_pose, joint_angles = [], []

        example = {
            "instruction": instruction,
            "tcp_pose": tcp_pose,             # [x,y,z,rx,ry,rz]
            "joint_angles": joint_angles,     # [q0,q1,q2,q3,q4,q5]
            "target_cell": target_cell        # from tracker
        }
        append_example(OUTPUT_PATH, example)
        print(f"Saved: {example}")

    # 4) Hand over to teleop loop (movement + record trigger)
    try:
        teleop.run_teleop(robot, tracker, on_record)
    finally:
        try:
            robot.close()
        except Exception:
            pass
        print("\nTeleop ended. Camera feed is STILL RUNNING.")
        print("➡ Press ESC in the camera window to close it and exit.")
        tracker.join()  # keep feed on until ESC

if __name__ == "__main__":
    main()
