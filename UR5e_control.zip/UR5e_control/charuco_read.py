# C:\Users\hitis\Desktop\UR5e_control\charuco_read.py
# Build a name map for the existing ChArUco board and send it to another function.
# Columns: A–J (left→right). Rows: 1–14 (bottom→top, as in your screenshot).

from typing import Dict, Callable
import json
import os

BOARD_PDF = r"C:\Users\hitis\Desktop\UR5e_control\ChArUco__A4.pdf"  # not used for mapping, kept for reference

SQUARES_X = 10                       # columns A..J
SQUARES_Y = 14                       # rows 1..14
COLUMN_LABELS = "ABCDEFGHIJ"         # must match SQUARES_X

def build_cell_map(
    squares_x: int = SQUARES_X,
    squares_y: int = SQUARES_Y,
    column_labels: str = COLUMN_LABELS
) -> Dict[str, Dict[str, int]]:
    """Return dict mapping 'A1'..'J14' to row/col indices.
    - row_1_based_bottom: 1..14 (bottom→top, like the printed board)
    - col_1_based_left:   1..10 (left→right)
    - row_index_top0:     0..13 (top→bottom, image-style)
    - col_index_left0:    0..9  (left→right)
    """
    if len(column_labels) != squares_x:
        raise ValueError("COLUMN_LABELS length must equal SQUARES_X")

    mapping: Dict[str, Dict[str, int]] = {}
    for r in range(1, squares_y + 1):          # 1 at bottom, 14 at top
        for c in range(1, squares_x + 1):
            name = f"{column_labels[c-1]}{r}"
            mapping[name] = {
                "row_1_based_bottom": r,
                "col_1_based_left": c,
                "row_index_top0": squares_y - r,  # convert to top-origin 0-based
                "col_index_left0": c - 1
            }
    return mapping

def send_map(cell_map: Dict[str, Dict[str, int]], receiver: Callable[[Dict[str, Dict[str, int]]], None]) -> None:
    """Send the map to any function you provide."""
    receiver(cell_map)

# --- Example receiver; replace with your own function ---
def consume_map(cell_map: Dict[str, Dict[str, int]]) -> None:
    # Minimal demo – replace with your integration point
    print(f"Cells: {len(cell_map)}")
    for k in ("A1", "J3", "J14"):
        print(k, "->", cell_map[k])

if __name__ == "__main__":
    cell_map = build_cell_map()

    # Save next to this script for convenience
    out_json = os.path.join(os.path.dirname(__file__), "charuco_cell_map.json")
    with open(out_json, "w") as f:
        json.dump(cell_map, f, indent=2)
    print(f"Saved map to {out_json}")

    # Send to your function (replace 'consume_map' with your target)
    send_map(cell_map, consume_map)
