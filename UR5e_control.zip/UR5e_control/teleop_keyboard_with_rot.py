import time
import sys
from contextlib import contextmanager
import os
import io
import math3d as m3d
import URBasic
from URBasic.kinematic import Invkine_manip, Forwardkin_manip

"""The termios, tty and select modules are only available on POSIX systems.
On Windows we will instead use msvcrt for key detection.  The imports
are therefore deferred based on the operating system to prevent
ImportError on Windows."""
if os.name != 'nt':
    import select  # POSIX only
    import termios
    import tty
else:
    import msvcrt  # Windows only


# ---------- Configuration ----------
# Adjust these values to suit your setup.
ROBOT_IP = "192.168.1.100"  # IP address of the UR5e controller
ACCELERATION = 0.4           # Tool acceleration [m/s²]
VELOCITY = 0.2               # Tool velocity [m/s]
STEP_SIZE = 0.01             # Position step for each key press [m]
STEP_ROT = 0.05  # rotational step size in radians (~2.86 degrees)



@contextmanager
def raw_mode(fileobj):
    """Context manager that puts the terminal into raw mode when possible.

    On POSIX systems the terminal settings are adjusted so that
    individual key presses can be read without waiting for a newline.
    On Windows no modifications are required because key reading is
    handled through the `msvcrt` module.  The argument `fileobj` is
    ignored on Windows.
    """
    # Use raw mode only on POSIX systems when a valid file descriptor
    # is provided.  Windows uses msvcrt for key reading so there is
    # nothing to configure here.  When fileobj is None the context
    # manager yields immediately.
    if os.name != 'nt' and fileobj is not None:
        # Save the current terminal settings and switch to cbreak mode.
        orig_attrs = termios.tcgetattr(fileobj)
        tty.setcbreak(fileobj)
        try:
            yield
        finally:
            termios.tcsetattr(fileobj, termios.TCSADRAIN, orig_attrs)
    else:
        # On Windows or when no file object provided, just yield.
        yield


def get_key(timeout=0.0):
    """Cross‑platform non‑blocking key press reader.

    When running on POSIX the function uses `select` and `sys.stdin` to
    poll for a single character without waiting for a newline.
    On Windows it uses the `msvcrt` module to detect and read key
    presses.  The optional `timeout` parameter is respected on POSIX,
    but ignored on Windows.

    Returns
    -------
    str | None
        The character pressed or `None` if no key press was detected.
    """
    if os.name == 'nt':
        # On Windows use msvcrt.kbhit() to test for a key press.  If
        # available read a Unicode character using getwch(), which
        # returns a string.  Otherwise return None.
        if msvcrt.kbhit():
            return msvcrt.getwch()
        else:
            # Sleep briefly to avoid busy waiting; timeout ignored
            time.sleep(timeout)
            return None
    else:
        dr, dw, de = select.select([sys.stdin], [], [], timeout)
        if dr:
            return sys.stdin.read(1)
        return None


def connect_robot():
    """Attempt to connect to the UR5e and return a handle.

    The URBasic library provides a high level wrapper around the
    various UR interfaces (RTDE, dashboard and real‑time client).
    Here we instantiate a `RobotModel` which holds kinematic
    information for the UR5e and then create a `UrScriptExt` object
    pointing at the controller.  If the connection fails an
    exception will propagate which callers may handle.
    """
    print("Connecting to robot at {} …".format(ROBOT_IP))
    # Build the internal kinematic model.  This is required by the
    # UrScriptExt constructor.
    model = URBasic.robotModel.RobotModel()
    robot = URBasic.urScriptExt.UrScriptExt(host=ROBOT_IP, robotModel=model)
    # Ensure any safety or protective stops are cleared and the
    # robot is ready for commands.
    robot.reset_error()
    return robot


def sanity_move(robot):
    """Perform a small joint movement as a connection sanity check.

    Query the current joint positions, move joint 0 by ±5° and then
    return it to its original position.  Any exception raised here
    usually indicates a connection or permission problem.
    """
    print("Performing sanity check on joint 0…")
    
    # Fetch the current joint positions first
    current_joints = list(robot.get_actual_joint_positions())
    print("Current joint angles [rad]: {}".format([
        round(float(j), 4) for j in current_joints  # Show joint angles in radians (rounded to 4 decimal places)
    ]))
    
    # Move joint 0 +5°
    joints_plus = current_joints.copy()
    joints_plus[0] += 5.0 * 3.141592653589793 / 180.0
    robot.movej(q=joints_plus, a=ACCELERATION, v=VELOCITY)
    time.sleep(1.0)
    
    # Move joint 0 –5°
    joints_minus = current_joints.copy()
    joints_minus[0] -= 5.0 * 3.141592653589793 / 180.0
    robot.movej(q=joints_minus, a=ACCELERATION, v=VELOCITY)
    time.sleep(1.0)
    print("Sanity check complete.")
    
    current_joints = list(robot.get_actual_joint_positions())
    # Convert joint angles from radians to degrees for display
    print("Current joint angles [rad]: {}".format([
        round(float(j), 4) for j in current_joints
    ]))
    
def teleop_loop(robot):
    print("\nTeleoperation started.")
    print("Translation: A/D (X), W/S (Y), R/F (Z)")
    print("Rotation:    J/L (Rx), I/K (Ry), U/O (Rz)")
    print("Q to quit.")

    fd = None
    if os.name != 'nt':
        try:
            fd = sys.stdin.fileno()
        except (AttributeError, io.UnsupportedOperation):
            fd = None

    with raw_mode(fd):
        while True:
            movement = input("Enter command: ").lower()
            if movement == 'q':
                print("Exiting teleoperation loop…")
                break

            pose = list(robot.get_actual_tcp_pose())
            moved = False

            # ---- Translation ----
            if movement == 'a':  # -X
                pose[0] -= STEP_SIZE
                moved = True
            elif movement == 'd':  # +X
                pose[0] += STEP_SIZE
                moved = True
            elif movement == 'w':  # +Y
                pose[1] += STEP_SIZE
                moved = True
            elif movement == 's':  # -Y
                pose[1] -= STEP_SIZE
                moved = True
            elif movement == 'r':  # +Z
                pose[2] += STEP_SIZE
                moved = True
            elif movement == 'f':  # -Z
                pose[2] -= STEP_SIZE
                moved = True

            # ---- Rotation ----
            elif movement == 'j':  # -Rx
                pose[3] -= STEP_ROT
                moved = True
            elif movement == 'l':  # +Rx
                pose[3] += STEP_ROT
                moved = True
            elif movement == 'i':  # +Ry
                pose[4] += STEP_ROT
                moved = True
            elif movement == 'k':  # -Ry
                pose[4] -= STEP_ROT
                moved = True
            elif movement == 'u':  # +Rz
                pose[5] += STEP_ROT
                moved = True
            elif movement == 'o':  # -Rz
                pose[5] -= STEP_ROT
                moved = True

            if moved:
                try:
                    robot.movel(pose, a=ACCELERATION, v=VELOCITY)
                    current_joints = list(robot.get_actual_joint_positions())
                    fk_position = Forwardkin_manip(current_joints, rob='ur5')
                    print("Current TCP Pose:", [round(float(x), 4) for x in pose])
                    print("Current TCP Position (FK):", [round(float(x), 4) for x in fk_position])
                except Exception as e:
                    print(f"Movement failed: {e}")
                    break


def main():
    """Entry point when this module is executed as a script."""
    try:
        robot = connect_robot()
        # Fetch the initial joint positions
        initial_joints = list(robot.get_actual_joint_positions())
        fk_position = Forwardkin_manip(initial_joints, rob='ur5')  # Use the correct robot model ('ur5' or 'ur10')
        print("Initial TCP Position (FK):", fk_position)
    except Exception as e:
        print("Failed to connect to robot: {}".format(e))
        return
    '''try:
        sanity_move(robot)
        # Fetch the current joint positions after sanity check
        current_joints = list(robot.get_actual_joint_positions())
        fk_position = Forwardkin_manip(current_joints, rob='ur5')  # Use the correct robot model ('ur5' or 'ur10')
        print("TCP Position (FK) After Sanity Check:", fk_position)
    except Exception as e:
        print("Sanity check failed: {}".format(e))
        robot.close()
        return'''
    try:
        teleop_loop(robot)
    except KeyboardInterrupt:
        print("Interrupted by user.")
    finally:
        # Always attempt to close the connection cleanly
        robot.close()


if __name__ == '__main__':
    main()
