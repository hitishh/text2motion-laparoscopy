# C:\Users\hitis\Desktop\UR5e_control\charuco_show_cell.py
# Type a cell name (e.g., A5). The script loads your PDF board,
# finds the grid, rectifies it, and shows just that cell.
# Uses the map from charuco_read.py.

import os
import re
import cv2
import numpy as np

# --- import your previous script's map builder ---
from charuco_read import build_cell_map, SQUARES_X, SQUARES_Y

# --- PDF -> image (uses PyMuPDF) ---
import fitz  # PyMuPDF

PDF_PATH = r"C:\Users\hitis\Desktop\UR5e_control\ChArUco__A4.pdf"
SCALE_PER_SQUARE = 100  # pixels per square in the rectified image

def render_pdf_first_page(pdf_path: str, dpi: int = 300) -> np.ndarray:
    doc = fitz.open(pdf_path)
    page = doc.load_page(0)
    zoom = dpi / 72.0
    mat = fitz.Matrix(zoom, zoom)
    pix = page.get_pixmap(matrix=mat, alpha=False)
    img = np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.h, pix.w, 3)
    img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
    doc.close()
    return img

def order_pts(pts):
    # pts: (4,2)
    rect = np.zeros((4, 2), dtype="float32")
    s = pts.sum(axis=1)
    rect[0] = pts[np.argmin(s)]  # TL
    rect[2] = pts[np.argmax(s)]  # BR
    diff = np.diff(pts, axis=1)
    rect[1] = pts[np.argmin(diff)]  # TR
    rect[3] = pts[np.argmax(diff)]  # BL
    return rect

def find_board_quad(img_bgr: np.ndarray) -> np.ndarray:
    """Return 4-point quadrilateral (TL,TR,BR,BL) of the inner board."""
    gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
    gray = cv2.equalizeHist(gray)
    thr = cv2.adaptiveThreshold(gray, 255,
                                cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                cv2.THRESH_BINARY_INV, 51, 5)
    # strengthen grid/border lines
    k = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5))
    thr = cv2.morphologyEx(thr, cv2.MORPH_CLOSE, k, iterations=2)

    cnts, _ = cv2.findContours(thr, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not cnts:
        raise RuntimeError("No contours found to locate the board.")

    cnts = sorted(cnts, key=cv2.contourArea, reverse=True)
    for c in cnts[:10]:  # check a few largest
        peri = cv2.arcLength(c, True)
        approx = cv2.approxPolyDP(c, 0.02 * peri, True)
        if len(approx) == 4 and cv2.isContourConvex(approx):
            quad = approx.reshape(-1, 2).astype(np.float32)
            return order_pts(quad)
    raise RuntimeError("Could not approximate a rectangular board area.")

def warp_board(img_bgr: np.ndarray, quad: np.ndarray) -> np.ndarray:
    width = SQUARES_X * SCALE_PER_SQUARE
    height = SQUARES_Y * SCALE_PER_SQUARE
    dst = np.array([[0, 0],
                    [width - 1, 0],
                    [width - 1, height - 1],
                    [0, height - 1]], dtype=np.float32)
    M = cv2.getPerspectiveTransform(quad, dst)
    return cv2.warpPerspective(img_bgr, M, (width, height))

def cell_to_roi(cell_name: str, H: int, W: int, cell_map: dict):
    # Validate input like A5, J14, etc.
    if not re.fullmatch(r"[A-Ja-j](?:[1-9]|1[0-4])", cell_name.strip()):
        raise ValueError("Cell must be A1..J14 (case-insensitive).")

    key = cell_name.upper()
    if key not in cell_map:
        raise ValueError(f"{key} not in map (valid: A1..J14).")

    info = cell_map[key]
    row_top0 = info["row_index_top0"]
    col_left0 = info["col_index_left0"]

    cell_w = W // SQUARES_X
    cell_h = H // SQUARES_Y

    x0 = int(col_left0 * cell_w)
    x1 = int((col_left0 + 1) * cell_w)
    y0 = int(row_top0 * cell_h)
    y1 = int((row_top0 + 1) * cell_h)
    return x0, y0, x1, y1

def main():
    # Build map from the previous script
    cell_map = build_cell_map()

    # Render PDF and rectify to top-down grid
    print("Loading and rectifying board from PDF...")
    page_img = render_pdf_first_page(PDF_PATH, dpi=300)
    quad = find_board_quad(page_img)
    board = warp_board(page_img, quad)

    H, W = board.shape[:2]
    print(f"Rectified board size: {W}x{H}px")

    while True:
        cell = input("Enter cell (A1..J14) or 'q' to quit: ").strip()
        if cell.lower() in ("q", "quit", "exit"):
            break
        try:
            x0, y0, x1, y1 = cell_to_roi(cell, H, W, cell_map)
            crop = board[y0:y1, x0:x1].copy()
            if crop.size == 0:
                print("Empty crop (unexpected). Try another cell.")
                continue
            # show and also save
            win = f"Cell {cell.upper()}"
            cv2.imshow(win, crop)
            out_name = f"cell_{cell.upper()}.png"
            out_path = os.path.join(os.path.dirname(__file__), out_name)
            cv2.imwrite(out_path, crop)
            print(f"Saved {out_name} next to this script.")
            cv2.waitKey(0)
            cv2.destroyWindow(win)
        except Exception as e:
            print("Error:", e)

if __name__ == "__main__":
    main()
