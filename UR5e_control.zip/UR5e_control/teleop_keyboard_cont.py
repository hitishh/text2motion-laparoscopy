import time
import sys
import msvcrt
import URBasic
from URBasic.kinematic import Invkine_manip, Forwardkin_manip

ROBOT_IP = "192.168.1.101"
ACCELERATION = 0.4
VELOCITY = 0.2
STEP_SIZE = 0.01


def connect_robot():
    print(f"Connecting to robot at {ROBOT_IP} …")
    model = URBasic.robotModel.RobotModel()
    robot = URBasic.urScriptExt.UrScriptExt(host=ROBOT_IP, robotModel=model)
    robot.reset_error()
    return robot


def sanity_move(robot):
    print("Performing sanity check on joint 0…")
    current_joints = list(robot.get_actual_joint_positions())
    print(f"Current joint angles [rad]: {[round(float(j), 4) for j in current_joints]}")  # Round to 4 decimals

    joints_plus = current_joints.copy()
    joints_plus[0] += 5.0 * 3.141592653589793 / 180.0
    robot.movej(q=joints_plus, a=ACCELERATION, v=VELOCITY)
    time.sleep(1.0)

    joints_minus = current_joints.copy()
    joints_minus[0] -= 5.0 * 3.141592653589793 / 180.0
    robot.movej(q=joints_minus, a=ACCELERATION, v=VELOCITY)
    time.sleep(1.0)
    print("Sanity check complete.")


def teleop_loop(robot):
    """Main teleoperation loop."""
    print("\nTeleoperation started. Use A/D (X-axis), W/S (Y-axis), R/F (Z-axis) to jog the tool; Q to quit.")
    print("Entering while loop...")
    
    while True:
        if msvcrt.kbhit():  # Check if a key is pressed
            print("Key detected!")
            ch = msvcrt.getwch()  # Get the key pressed
            print(f"Key pressed: {ch}")  # Debug print to confirm the input has been received

            if ch == 'q':
                print("Exiting teleoperation loop…")
                break

            pose = list(robot.get_actual_tcp_pose())
            moved = False
            if ch == 'a':  # −X
                pose[0] -= STEP_SIZE
                moved = True
            elif ch == 'd':  # +X
                pose[0] += STEP_SIZE
                moved = True
            elif ch == 'w':  # +Y
                pose[1] += STEP_SIZE
                moved = True
            elif ch == 's':  # −Y
                pose[1] -= STEP_SIZE
                moved = True
            elif ch == 'r':  # +Z
                pose[2] += STEP_SIZE
                moved = True
            elif ch == 'f':  # −Z
                pose[2] -= STEP_SIZE
                moved = True

            if moved:
                print(f"Moving robot to position: {[round(float(val), 4) for val in pose]}")  # Debug: Target position to move to
                try:
                    robot.movel(pose, a=ACCELERATION, v=VELOCITY)
                    current_joints = list(robot.get_actual_joint_positions())
                    fk_position = Forwardkin_manip(current_joints, rob='ur5')
                    print(f"Current TCP Position (FK): {[round(float(val), 4) for val in fk_position]}")  # Round to 4 decimals
                except Exception as e:
                    print(f"Movement failed: {e}")
                    break

        time.sleep(0.05)  # Short delay to avoid high CPU usage


def main():
    try:
        robot = connect_robot()
        initial_joints = list(robot.get_actual_joint_positions())
        fk_position = Forwardkin_manip(initial_joints, rob='ur5')
        print("Initial TCP Position (FK):", fk_position)
    except Exception as e:
        print(f"Failed to connect to robot: {e}")
        return

    try:
        sanity_move(robot)
        current_joints = list(robot.get_actual_joint_positions())
        fk_position = Forwardkin_manip(current_joints, rob='ur5')
        print("TCP Position (FK) After Sanity Check:", fk_position)
    except Exception as e:
        print(f"Sanity check failed: {e}")
        robot.close()
        return

    try:
        teleop_loop(robot)
    except KeyboardInterrupt:
        print("Interrupted by user.")
    finally:
        robot.close()


if __name__ == '__main__':
    main()
