"""
charuco_teleop_dataset.py
=========================

This module combines three separate pieces of functionality into a single
command‑line program:

1. **ChArUco board analysis** – At startup we derive a mapping from
   detected ArUco marker IDs to a human friendly row/column label
   (e.g. "G8") for a specific ChArUco calibration board.  The board
   dimensions and dictionary are fixed to match the user’s physical board
   (10 columns × 14 rows using a 4×4 ArUco dictionary).  Rather than
   decoding a PDF at runtime we construct an equivalent board using
   OpenCV’s `CharucoBoard_create()` function; the marker IDs on the
   generated board match those printed on the physical board.  A lookup
   table is created so that during live detection we can convert a
   marker ID into the corresponding chessboard cell label.

2. **UR5e teleoperation** – The teleoperation loop is based on the
   provided `teleop_keyboard_with_rot.py` script.  It connects to the
   robot using the URBasic library, clears any faults, and then lets
   the user jog the tool in discrete steps.  The keys are mapped as
   follows:

   - **Translation**: A/D move ±X, W/S move ±Y, R/F move ±Z (step
     defined by `STEP_SIZE`, default 10 mm).
   - **Rotation**: J/L rotate ±Rx, I/K rotate ±Ry, U/O rotate ±Rz
     (step defined by `STEP_ROT`, default ~0.05 rad).
   - **C**: Capture a dataset sample (see below).
   - **Q**: Quit the program.

3. **Dataset capture** – When the user presses **C** the program
   performs a standardised data acquisition.  It prompts for a natural
   language command, reads the robot’s current TCP pose and joint
   angles, captures a frame from the camera, identifies the ArUco
   marker nearest to the image centre and converts its ID into a
   chessboard label using the lookup table.  The proposed cell is
   presented to the user for confirmation or correction.  A JSON record
   containing the NL command, TCP pose, joint angles and target cell is
   appended to an in‑memory list.  This list can later be saved to
   disk or used to fine tune an LLM.

The script requires the OpenCV "aruco" module (available via the
`opencv-contrib-python` package) and the URBasic package.  If your
environment lacks these dependencies the code will still load but will
raise an exception when invoked.  You should run this script on the
machine connected to the UR5e and the camera.  Make sure the
environment variable `UR5E_IP` is set or supply the controller IP
address when prompted at startup.
"""

import os
import sys
import json
import time
from contextlib import contextmanager
from typing import Dict, Tuple, List, Optional

import math3d as m3d  # type: ignore

# Import URBasic only when available.  When writing this script outside of
# the robot environment the import may fail; the functions that depend
# upon URBasic are protected accordingly.
try:
    import URBasic  # type: ignore
except ImportError as e:
    URBasic = None  # type: ignore

# Optional OpenCV import; the aruco submodule is part of opencv‑contrib
try:
    import cv2  # type: ignore
    from cv2 import aruco  # type: ignore
except ImportError as e:
    cv2 = None  # type: ignore
    aruco = None  # type: ignore


# ---------------------------------------------------------------------------
# Configuration
#
# Adjust these values to suit your hardware.  STEP_SIZE defines the
# translational jog in metres (0.01 m = 10 mm) and STEP_ROT defines the
# rotational jog in radians (~0.05 rad ≈ 2.86°).
ACCELERATION = 0.4  # Tool acceleration [m/s²]
VELOCITY = 0.2      # Tool velocity [m/s]
STEP_SIZE = 0.01    # Translation step [m]
STEP_ROT = 0.05     # Rotation step [rad]

# ChArUco board definition (10 columns × 14 rows using a 4×4 ArUco dictionary)
CHARUCO_COLUMNS = 10
CHARUCO_ROWS = 14
# The lengths here are arbitrary; they do not affect the ID layout.  Units are
# metres.  They only matter when computing real‑world coordinates (which we
# don’t use here).  Feel free to adjust these to match your board if you
# intend to perform pose estimation.
SQUARE_LENGTH = 0.04  # 40 mm squares
MARKER_LENGTH = 0.02  # 20 mm markers within the squares
ARUCO_DICT_ID = aruco.DICT_4X4_250 if aruco is not None else None


@contextmanager
def raw_mode(fileobj):
    """Context manager to set the terminal into raw mode on POSIX systems.

    Raw mode allows us to read single characters without waiting for
    newline.  On Windows this context manager does nothing because key
    reading is handled via `msvcrt`.

    Parameters
    ----------
    fileobj : file descriptor or None
        The underlying file descriptor for stdin.  When None the
        context manager has no effect.
    """
    if os.name != 'nt' and fileobj is not None:
        import termios
        import tty
        orig_attrs = termios.tcgetattr(fileobj)
        tty.setcbreak(fileobj)
        try:
            yield
        finally:
            termios.tcsetattr(fileobj, termios.TCSADRAIN, orig_attrs)
    else:
        yield


def prompt_robot_ip() -> str:
    """Prompt the user for the UR5e controller IP address.

    If the environment variable `UR5E_IP` is set it will be offered as
    the default.  The returned string is never empty.

    Returns
    -------
    str
        The IP address entered by the user or the default value.
    """
    default_ip = os.environ.get("UR5E_IP", "192.168.1.100")
    prompt = f"Enter UR5e IP address [{default_ip}]: "
    ip = input(prompt).strip() or default_ip
    return ip


def connect_robot(ip: str):
    """Establish a connection to the UR5e controller.

    A `UrScriptExt` instance is returned after clearing any error states
    on the robot.  If URBasic is unavailable an exception is raised.

    Parameters
    ----------
    ip : str
        The IP address of the controller.

    Returns
    -------
    URBasic.urScriptExt.UrScriptExt
        A handle for communicating with the robot.
    """
    if URBasic is None:
        raise RuntimeError(
            "URBasic is not installed; this script must be executed on the robot control PC with URBasic available."
        )
    print(f"Connecting to robot at {ip}…")
    model = URBasic.robotModel.RobotModel()
    robot = URBasic.urScriptExt.UrScriptExt(host=ip, robotModel=model)
    # Clear any safety or protective stops.
    robot.reset_error()
    return robot


def create_charuco_mapping() -> Dict[int, str]:
    """Generate a mapping from ArUco marker ID to chessboard cell label.

    We build an equivalent ChArUco board in memory with the same
    dimensions and dictionary as the physical board.  OpenCV assigns
    marker IDs sequentially in row‑major order starting from the top
    left.  To label the board in the user’s preferred orientation we
    assume column letters (A…J) run left→right and row numbers (1…14)
    run bottom→top.  The returned dictionary maps each integer marker ID
    to a string like ``"G8"``.

    Returns
    -------
    Dict[int, str]
        A lookup table from marker ID to human friendly label.
    """
    if aruco is None:
        raise RuntimeError(
            "OpenCV ArUco module not available; install opencv‑contrib‑python to use ChArUco functionality."
        )
    # Create the board.  The actual square and marker lengths are not
    # important for ID mapping; they are included for completeness.
    dictionary = aruco.getPredefinedDictionary(ARUCO_DICT_ID)
    board = aruco.CharucoBoard_create(
        squaresX=CHARUCO_COLUMNS,
        squaresY=CHARUCO_ROWS,
        squareLength=SQUARE_LENGTH,
        markerLength=MARKER_LENGTH,
        dictionary=dictionary,
    )
    mapping: Dict[int, str] = {}
    ids = board.ids.flatten().tolist()
    for idx, marker_id in enumerate(ids):
        row_index = idx // CHARUCO_COLUMNS  # 0 at top
        col_index = idx % CHARUCO_COLUMNS
        # Row numbers increase from bottom to top (1…14)
        row_label = CHARUCO_ROWS - row_index
        # Column letters A…J from left to right
        col_label = chr(ord('A') + col_index)
        mapping[int(marker_id)] = f"{col_label}{row_label}"
    return mapping


def detect_focus_marker(
    frame,
    aruco_dict: "cv2.aruco_Dictionary",
    mapping: Dict[int, str],
) -> Tuple[Optional[int], Optional[str]]:
    """Detect ArUco markers in an image and return the ID and label of
    the marker closest to the image centre.

    Parameters
    ----------
    frame : ndarray
        A colour image from the camera (BGR format).
    aruco_dict : cv2.aruco_Dictionary
        The dictionary used for detection.
    mapping : Dict[int, str]
        Lookup table from marker ID to cell label.  If the detected ID
        is not present in this dictionary the label will be ``None``.

    Returns
    -------
    tuple
        ``(best_id, label)`` where ``best_id`` is the ID of the marker
        nearest the centre of the image and ``label`` is its mapped
        chessboard label.  If no markers are found both values are
        ``None``.
    """
    if aruco is None or frame is None:
        return None, None
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    parameters = aruco.DetectorParameters_create()
    corners, ids, _ = aruco.detectMarkers(gray, aruco_dict, parameters=parameters)
    if ids is None or len(ids) == 0:
        return None, None
    # Compute image centre in pixel coordinates
    h, w = gray.shape[:2]
    centre = (w / 2.0, h / 2.0)
    best_dist = float("inf")
    best_id: Optional[int] = None
    for marker_corners, marker_id in zip(corners, ids.flatten()):
        pts = marker_corners.reshape((4, 2))
        cx, cy = pts.mean(axis=0)
        dist_sq = (cx - centre[0]) ** 2 + (cy - centre[1]) ** 2
        if dist_sq < best_dist:
            best_dist = dist_sq
            best_id = int(marker_id)
    label: Optional[str] = mapping.get(best_id) if best_id is not None else None
    return best_id, label


def teleop_and_capture(robot):
    """Main loop for teleoperation and dataset capture.

    The user can jog the TCP using the A/D, W/S, R/F, J/L, I/K, U/O keys.
    Pressing 'c' triggers data capture; pressing 'q' exits.  Captured
    records are stored in the `dataset` list and printed on screen.

    Parameters
    ----------
    robot : URBasic.urScriptExt.UrScriptExt
        Connected robot instance.
    """
    # Create the ArUco dictionary and mapping once at the start.  If
    # installation is incomplete this will raise, alerting the user.
    mapping = create_charuco_mapping()
    dictionary = aruco.getPredefinedDictionary(ARUCO_DICT_ID)
    print("ChArUco marker mapping loaded ({} entries).".format(len(mapping)))

    # Attempt to open the default camera; on failure disable detection.
    cap = None
    if cv2 is not None:
        try:
            cap = cv2.VideoCapture(0)
            if not cap.isOpened():
                print("Warning: Could not open camera. Marker detection disabled.")
                cap.release()
                cap = None
        except Exception as e:
            print(f"Warning: Camera initialisation failed: {e}")
            cap = None
    else:
        print("Warning: OpenCV not installed. Marker detection disabled.")

    dataset: List[Dict[str, object]] = []

    print("\nTeleoperation controls:")
    print("  Translation: A/D (±X), W/S (±Y), R/F (±Z) [step = {:.0f} mm]".format(STEP_SIZE * 1000))
    print("  Rotation:    J/L (±Rx), I/K (±Ry), U/O (±Rz) [step ≈ {:.2f} rad]".format(STEP_ROT))
    print("  C: Capture sample")
    print("  Q: Quit")

    fd = None
    if os.name != 'nt':
        try:
            fd = sys.stdin.fileno()
        except Exception:
            fd = None

    with raw_mode(fd):
        while True:
            # Read user command.  Using `input()` here simplifies cross‑platform
            # behaviour.  It does mean you need to press Enter after each
            # command.  If you want single keypress behaviour replace this
            # with a non‑blocking key reader as in the original script.
            cmd = input("Enter command: ").strip().lower()
            if cmd == 'q':
                print("Exiting teleoperation…")
                break
            # Jog the robot
            pose = list(robot.get_actual_tcp_pose())
            moved = False
            if cmd == 'a':  # –X
                pose[0] -= STEP_SIZE
                moved = True
            elif cmd == 'd':  # +X
                pose[0] += STEP_SIZE
                moved = True
            elif cmd == 'w':  # +Y
                pose[1] += STEP_SIZE
                moved = True
            elif cmd == 's':  # –Y
                pose[1] -= STEP_SIZE
                moved = True
            elif cmd == 'r':  # +Z
                pose[2] += STEP_SIZE
                moved = True
            elif cmd == 'f':  # –Z
                pose[2] -= STEP_SIZE
                moved = True
            elif cmd == 'j':  # –Rx
                pose[3] -= STEP_ROT
                moved = True
            elif cmd == 'l':  # +Rx
                pose[3] += STEP_ROT
                moved = True
            elif cmd == 'i':  # +Ry
                pose[4] += STEP_ROT
                moved = True
            elif cmd == 'k':  # –Ry
                pose[4] -= STEP_ROT
                moved = True
            elif cmd == 'u':  # +Rz
                pose[5] += STEP_ROT
                moved = True
            elif cmd == 'o':  # –Rz
                pose[5] -= STEP_ROT
                moved = True

            if moved:
                try:
                    robot.movel(pose, a=ACCELERATION, v=VELOCITY)
                    current_joints = list(robot.get_actual_joint_positions())
                    # Convert to float for readability
                    print("Current TCP pose:", [round(float(x), 4) for x in pose])
                    print(
                        "Current joint angles:",
                        [round(float(x), 4) for x in current_joints],
                    )
                except Exception as e:
                    print(f"Movement failed: {e}")
                    break
            elif cmd == 'c':
                # Capture a dataset sample
                nl = input("Enter the natural‑language command for this pose: ").strip()
                # Robot state
                tcp_pose = [float(x) for x in robot.get_actual_tcp_pose()]
                joint_angles = [float(x) for x in robot.get_actual_joint_positions()]
                # Camera detection
                detected_id: Optional[int] = None
                label: Optional[str] = None
                if cap is not None:
                    ret, frame = cap.read()
                    if ret:
                        detected_id, label = detect_focus_marker(frame, dictionary, mapping)
                    else:
                        print("Warning: Failed to grab frame from camera.")
                # Propose the cell label to the user
                cell_prompt = "Detected marker ID {} mapped to cell {}.".format(
                    detected_id if detected_id is not None else "None",
                    label if label is not None else "Unknown",
                )
                print(cell_prompt)
                override = input(
                    "Enter target cell label to confirm or override (e.g. E9), or press Enter to accept: "
                ).strip().upper()
                final_label = override if override else (label or "")
                record = {
                    "command": nl,
                    "tcp_pose": tcp_pose,
                    "joint_angles": joint_angles,
                    "target_cell": final_label,
                }
                dataset.append(record)
                print(f"Captured sample {len(dataset)}: {json.dumps(record, indent=2)}")
            else:
                print("Unrecognised command.")
    # Clean up the camera
    if cap is not None:
        cap.release()
    # Report the number of collected samples
    print(f"Collected {len(dataset)} samples.")
    # Optionally write the dataset to disk
    if dataset:
        save_path = input(
            "Enter filename to save the dataset as JSON (or press Enter to skip saving): "
        ).strip()
        if save_path:
            try:
                with open(save_path, 'w', encoding='utf-8') as fh:
                    json.dump(dataset, fh, indent=2)
                print(f"Dataset saved to {save_path}.")
            except Exception as e:
                print(f"Failed to save dataset: {e}")


def main():
    """Entry point for the command‑line script.

    Connects to the UR5e, performs an optional sanity check, and
    launches the teleoperation/data capture loop.  The user can quit
    the loop with 'q'.  At the end the user is offered the option to
    save the collected dataset to a JSON file.
    """
    try:
        ip = prompt_robot_ip()
        robot = connect_robot(ip)
        # Print initial pose for reference
        initial_joints = list(robot.get_actual_joint_positions())
        print(
            "Initial joint angles [rad]:",
            [round(float(j), 4) for j in initial_joints],
        )
    except Exception as e:
        print(f"Error connecting to robot: {e}")
        return
    try:
        teleop_and_capture(robot)
    except KeyboardInterrupt:
        print("Interrupted by user.")
    finally:
        try:
            robot.close()
        except Exception:
            pass


if __name__ == '__main__':
    main()