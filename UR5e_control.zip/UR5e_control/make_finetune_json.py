#!/usr/bin/env python3
# make_finetune_json.py
# Convert llm_urbasic_final.jsonl -> fine_tune_llm_final.json
# Format:
#   prompt   = "<|im_start|>user\n{instruction}<|im_end|>\n<|im_start|>assistant\n"
#   completion = raw output_code (code only)

import json, argparse, os, sys

TEMPLATE = "<|im_start|>user\n{instruction}<|im_end|>\n<|im_start|>assistant\n"

def load_jsonl(path):
    rows = []
    with open(path, "r", encoding="utf-8") as f:
        for i, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError as e:
                print(f"[WARN] Skipping bad JSONL line {i}: {e}", file=sys.stderr)
                continue
            rows.append(obj)
    return rows

def sanitize_code(code: str) -> str:
    # Ensure code is plain (no backticks), and ends with a newline for clean training
    code = code.replace("```python", "").replace("```", "")
    if not code.endswith("\n"):
        code += "\n"
    return code

def main():
    ap = argparse.ArgumentParser(description="Rewrite dataset to Qwen chat-style prompt/completion JSON.")
    ap.add_argument("--infile",  default="llm_urbasic_final.jsonl", help="Input JSONL with {instruction, output_code}")
    ap.add_argument("--outfile", default="fine_tune_llm_final.json", help="Output JSON file (array of objects)")
    ap.add_argument("--dedup", action="store_true", help="Optional: dedup by (instruction, output_code)")
    args = ap.parse_args()

    if not os.path.exists(args.infile):
        print(f"[ERROR] Input file not found: {args.infile}", file=sys.stderr)
        sys.exit(1)

    base = load_jsonl(args.infile)
    if not base:
        print(f"[ERROR] No usable rows loaded from {args.infile}", file=sys.stderr)
        sys.exit(1)

    out = []
    seen = set()

    for r in base:
        instr = (r.get("instruction") or "").strip()
        code  = (r.get("output_code") or "")
        if not instr or not code:
            continue

        prompt = TEMPLATE.format(instruction=instr)
        completion = sanitize_code(code)

        if args.dedup:
            key = (prompt, completion)
            if key in seen:
                continue
            seen.add(key)

        out.append({"prompt": prompt, "completion": completion})

    with open(args.outfile, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)

    print(f"Converted: {len(out)} examples")
    print(f"Wrote: {args.outfile}")

if __name__ == "__main__":
    main()
