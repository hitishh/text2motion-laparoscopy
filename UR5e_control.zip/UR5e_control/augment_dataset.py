
import argparse
import json
import random
import re
from collections import defaultdict, Counter
from math import ceil

CELL_RE = re.compile(r"^[A-J](?:[1-9]|1[0-4])$", re.I)

# ----------------- Paraphrase templates -----------------
CENTER_TPL = [
    "Centre on {cell}.",
    "Focus on {cell}.",
    "Put {cell} dead-centre.",
    "Aim the scope at {cell}.",
    "Frame {cell} in the middle.",
    "Lock the view on {cell}.",
    "Keep {cell} centred.",
    "Place {cell} at the crosshair.",
    "Hold here on {cell}.",
]

ZOOMIN_TPL = [
    "Zoom in slightly on {cell}.",
    "Zoom in a touch on {cell}.",
    "Tighten the view on {cell}.",
    "Give me a close-up of {cell}.",
    "Move 5 mm closer at {cell}.",
    "Move 10 mm closer at {cell}.",
]

ZOOMOUT_TPL = [
    "Zoom out slightly at {cell}.",
    "Zoom out a touch at {cell}.",
    "Widen the view at {cell}.",
    "Pull back 5 mm at {cell}.",
    "Pull back 10 mm at {cell}.",
]

COMPOUND_TPL = [
    "Pan right a little, then centre {cell}.",
    "Pan left slightly and re-centre {cell}.",
    "Tilt up 5°, settle on {cell}.",
    "Level the horizon, then lock {cell}.",
    "Roll clockwise 8°, keep {cell} centred.",
    "Track across, end on {cell}.",
]

PRECISION_TPL = [
    "Centre {cell} within ±2 mm.",
    "Keep {cell} centred; no drift.",
]

# Map detected category -> template bank
CATEGORY_TPL = {
    "center": CENTER_TPL,
    "zoomin": ZOOMIN_TPL,
    "zoomout": ZOOMOUT_TPL,
    "compound": COMPOUND_TPL,
    "precision": PRECISION_TPL,
}

# ----------------- Classifier for current instruction -----------------
def categorize_instruction(text: str) -> str:
    t = text.lower()
    if any(k in t for k in ["zoom in", "close-up", "closer", "tighten"]):
        return "zoomin"
    if any(k in t for k in ["zoom out", "widen", "pull back"]):
        return "zoomout"
    if any(k in t for k in ["pan ", "tilt", "roll", "level", "track"]):
        return "compound"
    if any(k in t for k in ["±", "+/-", "no drift", "within "]):
        return "precision"
    if any(k in t for k in ["centre", "center", "focus", "aim", "frame", "lock", "crosshair", "hold"]):
        return "center"
    return "center"

def parse_restrict_rows(rows_arg: str | None):
    if not rows_arg:
        return None
    parts = rows_arg.split("-")
    if len(parts) == 1:
        r = int(parts[0])
        return set([r])
    lo, hi = int(parts[0]), int(parts[1])
    if lo > hi:
        lo, hi = hi, lo
    return set(range(lo, hi+1))

def parse_cols_list(cols_arg: str | None):
    if not cols_arg:
        return None
    cols = [c.strip().upper() for c in cols_arg.split(",") if c.strip()]
    return set(cols) if cols else None

def load_jsonl(path: str):
    recs = []
    with open(path, "r", encoding="utf-8") as f:
        for ln, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except Exception:
                continue
            cell = str(obj.get("target_cell","")).strip().upper()
            if not CELL_RE.match(cell):
                continue
            instr = str(obj.get("instruction","")).strip()
            if not instr:
                continue
            pose = obj.get("tcp_pose")
            joints = obj.get("joint_angles")
            if not (isinstance(pose, list) and isinstance(joints, list)):
                continue
            recs.append(obj)
    return recs

def filter_allowed_cells(cells: set[str], restrict_rows, restrict_cols, exclude_cells):
    allowed = set()
    for c in cells:
        col = c[0].upper()
        row = int(c[1:])
        if restrict_rows and row not in restrict_rows:
            continue
        if restrict_cols and col not in restrict_cols:
            continue
        if exclude_cells and c.upper() in exclude_cells:
            continue
        allowed.add(c)
    return allowed

def build_seen_by_cell(recs):
    from collections import defaultdict
    by_cell = defaultdict(list)
    for obj in recs:
        cell = obj["target_cell"].upper()
        by_cell[cell].append(obj)
    return by_cell

def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True, help="Input JSONL path")
    ap.add_argument("--output", required=True, help="Output JSONL path")
    group = ap.add_mutually_exclusive_group(required=True)
    group.add_argument("--target-per-cell", type=int, help="Desired total examples per (allowed) cell after augmentation")
    group.add_argument("--total-target", type=int, help="Desired total number of examples overall after augmentation")
    ap.add_argument("--restrict-rows", help="Row range like 1-6; default None (no restriction)")
    ap.add_argument("--restrict-cols", help="Comma list of columns like C,D,E,F,G,H,I; default None")
    ap.add_argument("--exclude-cells", help="Comma list of exact cells to exclude (e.g., I2,I4,I6)")
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    random.seed(args.seed)

    recs = load_jsonl(args.input)
    if not recs:
        raise SystemExit("No valid records in input.")

    cells_present = set(obj["target_cell"].upper() for obj in recs if CELL_RE.match(obj.get("target_cell","").upper()))

    restrict_rows = parse_restrict_rows(args.restrict_rows)
    restrict_cols = parse_cols_list(args.restrict_cols)
    exclude_cells = set([c.strip().upper() for c in args.exclude_cells.split(",")]) if args.exclude_cells else set()

    allowed_cells = filter_allowed_cells(cells_present, restrict_rows, restrict_cols, exclude_cells)
    if not allowed_cells:
        allowed_cells = cells_present

    by_cell = build_seen_by_cell(recs)

    # Determine how many augmented examples we need per cell.
    #
    # If a total_target is provided, distribute the remaining examples evenly
    # across all allowed cells.  Use floor division to compute the base
    # amount to add to each cell, then spread any remainder across the first
    # few cells in a deterministic ordering.  This avoids overshooting
    # the requested total by pegging every cell to the maximum existing
    # count plus a ceiling, which was the previous behaviour.  If no
    # total_target is provided, fallback to a uniform target_per_cell.
    per_cell_target = None
    target_per_cell = None
    if args.total_target:
        # Number of cells we are allowed to augment
        n_cells = len(allowed_cells)
        if n_cells == 0:
            raise SystemExit("No allowed cells found to compute total target.")
        # Count current number of examples across all allowed cells
        current_total = sum(len(by_cell.get(c, [])) for c in allowed_cells)
        # Remaining examples needed to reach the overall target
        remaining = max(0, args.total_target - current_total)
        # Base number of examples to add to each cell
        base_add = remaining // n_cells
        # Remainder distributed to first few cells
        remainder = remaining % n_cells
        # Build a per-cell target map
        per_cell_target = {}
        # Sort cells deterministically by row then column so remainder
        # distribution is consistent
        ordered_cells = sorted(allowed_cells, key=lambda s:(int(s[1:]), s[0]))
        for i, c in enumerate(ordered_cells):
            have = len(by_cell.get(c, []))
            add = base_add + (1 if i < remainder else 0)
            per_cell_target[c] = have + add
    else:
        # Uniform target-per-cell mode
        target_per_cell = args.target_per_cell

    existing_pairs = set()
    for obj in recs:
        cell = obj["target_cell"].upper()
        instruction = obj["instruction"].strip()
        existing_pairs.add((cell, instruction))

    augmented = list(recs)

    for cell in sorted(allowed_cells):
        items = list(by_cell.get(cell, []))
        count_now = len(items)
        # Determine desired total for this cell
        if per_cell_target is not None:
            target_for_cell = per_cell_target.get(cell, 0)
        else:
            target_for_cell = target_per_cell
        # If we've already met or exceeded the target for this cell, skip it
        if count_now >= target_for_cell:
            continue

        need = target_for_cell - count_now
        # If no existing items for the cell, skip augmentation (we cannot seed
        # new examples without a base record)
        if not items:
            continue

        base_cats = [categorize_instruction(o["instruction"]) for o in items]
        if not base_cats:
            base_cats = ["center"]
        cat_cycle = base_cats + ["center","zoomin","zoomout","compound","precision"]

        made = 0
        idx = 0
        while made < need:
            base = items[idx % len(items)]
            idx += 1
            cat = categorize_instruction(base["instruction"]) if random.random() < 0.7 else random.choice(cat_cycle)
            bank = CATEGORY_TPL.get(cat, CENTER_TPL)

            tried = 0
            chosen = None
            while tried < 10:
                tmpl = random.choice(bank)
                candidate = tmpl.format(cell=cell)
                if (cell, candidate) not in existing_pairs:
                    chosen = candidate
                    break
                tried += 1
            if not chosen:
                chosen = f"Centre on {cell}."
                if (cell, chosen) in existing_pairs:
                    chosen = f"Centre on {cell}. "

            new_obj = {
                "instruction": chosen,
                "tcp_pose": list(base["tcp_pose"]),
                "joint_angles": list(base["joint_angles"]),
                "target_cell": cell
            }
            augmented.append(new_obj)
            existing_pairs.add((cell, chosen))
            made += 1

    with open(args.output, "w", encoding="utf-8") as f:
        for obj in augmented:
            f.write(json.dumps(obj, ensure_ascii=False) + "\n")

    counts = Counter(o["target_cell"].upper() for o in augmented if CELL_RE.match(o["target_cell"].upper()))
    print("Augmentation complete.")
    print(f"Cells allowed: {len(allowed_cells)}")
    if per_cell_target is not None:
        print("Target per cell: variable (distributed for total target)")
    else:
        print(f"Target per cell: {target_per_cell}")
    print("Per-cell counts (allowed):")
    # Print counts for allowed cells sorted by row then column
    for c in sorted(allowed_cells, key=lambda s: (int(s[1:]), s[0])):
        print(f"{c}: {counts.get(c, 0)}")

if __name__ == "__main__":
    main()
