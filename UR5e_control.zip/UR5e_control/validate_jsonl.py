import json, re, sys
from collections import Counter

FN = "llm_charuco_ur5e_aug_600.jsonl"   # change if needed

CELL_RE = re.compile(r"^[A-J](?:[1-9]|1[0-4])$")
MENTION_RE = re.compile(r"\b([A-J](?:1[0-4]|[1-9]))\b", re.I)

def is_allowed_marker(cell):
    col = cell[0]; row = int(cell[1:])
    if row not in {1,2,3,4,5,6}: return False
    if col not in set("CDEFGHI"): return False
    if cell in {"I2","I4","I6"}: return False
    # markers: odd rows D,F,H; even rows C,E,G,I
    return (row%2==1 and col in {"D","F","H"}) or (row%2==0 and col in {"C","E","G","I"})

recs, dups, seen = [], 0, set()
with open(FN, "r", encoding="utf-8") as f:
    for i, line in enumerate(f, 1):
        line=line.strip()
        if not line: continue
        try:
            o=json.loads(line)
        except: 
            continue
        instr=o.get("instruction","")
        pose=o.get("tcp_pose",[])
        joints=o.get("joint_angles",[])
        cell=str(o.get("target_cell","")).upper()
        if not (instr and CELL_RE.match(cell) and isinstance(pose,list) and len(pose)==6 and isinstance(joints,list) and len(joints)==6):
            continue
        key=(instr, tuple(pose), tuple(joints), cell)
        if key in seen: dups+=1
        else: seen.add(key)
        recs.append(o)

# cell mention check
mism=0
for o in recs:
    m = MENTION_RE.search(o["instruction"])
    if m and m.group(1).upper()!=o["target_cell"].upper():
        mism+=1

# coverage
cnt = Counter(r["target_cell"].upper() for r in recs)
allowed = {c:n for c,n in cnt.items() if is_allowed_marker(c)}
non_allowed = {c:n for c,n in cnt.items() if c not in allowed}

print("Records:", len(recs))
print("Exact duplicates:", dups)
print("Instruction↔cell mismatches:", mism)
print("Allowed marker cells:", len(allowed), "Non-allowed cells:", len(non_allowed))
print("Allowed per-cell range:", (min(allowed.values()) if allowed else 0), "to", (max(allowed.values()) if allowed else 0))
if non_allowed:
    top = sorted(non_allowed.items(), key=lambda kv: -kv[1])[:10]
    print("Top non-allowed cells (count):", top)
