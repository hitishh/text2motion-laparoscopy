# rebuild_TbP.py
import numpy as np, math

# === Fill with your recorded top entry pose (mm, rad) ===
TOP_p_mm = np.array([510.13, -111.66, 136.91], dtype=float)
TOP_r = np.array([0.437, 1.653, -1.413], dtype=float)  # rx, ry, rz (rad)
TIP_TO_TROCAR_M = 0.250  # 25 cm

def axis_angle_to_R(rx, ry, rz):
    a = (rx*rx+ry*ry+rz*rz)**0.5
    if a < 1e-9: return np.eye(3)
    ux,uy,uz = rx/a, ry/a, rz/a
    c,s = math.cos(a), math.sin(a); C = 1-c
    return np.array([
        [c+ux*ux*C, ux*uy*C-uz*s, ux*uz*C+uy*s],
        [uy*ux*C+uz*s, c+uy*uy*C, uy*uz*C-ux*s],
        [uz*ux*C-uy*s, uz*uy*C+ux*s, c+uz*uz*C]
    ])

R_bC = axis_angle_to_R(*TOP_r)
tip_b = TOP_p_mm / 1000.0
trocar_b = tip_b - R_bC[:,2] * TIP_TO_TROCAR_M   # pivot = tip - 0.25m along +Z_cam

TbP = np.eye(4)
TbP[:3,:3] = R_bC            # align +Z_P with the scope axis at entry
TbP[:3, 3] = trocar_b        # origin at the trocar

np.save("TbP.npy", TbP)
print("Saved TbP.npy")
print("Trocar (base) [m]:", trocar_b)
