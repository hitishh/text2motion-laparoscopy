# collect_llm_instructions.py
# Orchestrates everything:
# - starts CenterCellTracker (charuco_center_cell.py)
# - connects to robot
# - calls teleop.run_teleop(robot, tracker, on_record)
# - on_record() prompts for instruction and saves:
#   {instruction, tcp_pose, joint_angles, target_cell}
# Camera feed remains ON until you press ESC in the window.

import os
import json
import re
import time

from charuco_center_cell import CenterCellTracker       # camera + cell identification
import teleop_with_center_cell_import as teleop         # robot teleop (modified module)

OUTPUT_PATH  = os.path.join(os.path.dirname(__file__), "llm_charuco_ur5e.jsonl")
CAM_INDEX    = 0

# -------------------- NEW: small template set for batch autosave --------------------
TEMPLATES = [
    "Centre on {CELL}.",
    "Focus on {CELL}.",
    "Put {CELL} dead-centre.",
    "Zoom in slightly on {CELL}.",
    "Zoom out slightly at {CELL}."
]
CELL_RE = re.compile(r"^[A-J](?:[1-9]|1[0-4])$", re.IGNORECASE)

def append_example(path: str, example: dict):
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(example, ensure_ascii=False) + "\n")

def normalize_cell(s: str | None) -> str | None:
    if not s:
        return None
    s = s.strip().upper()
    return s if CELL_RE.match(s) else None

def main():
    robot_ip = input("Enter UR5e IP (e.g., 192.168.1.100): ").strip()
    if not robot_ip:
        print("No IP provided."); return

    # 1) Start the tracker (window stays ON; press ESC to close at the end)
    tracker = CenterCellTracker(cam_index=CAM_INDEX, visualize=True, verbose=False)
    tracker.start()

    # 2) Connect the robot
    try:
        robot = teleop.connect_robot(robot_ip)
    except Exception as e:
        print(f"Robot connection failed: {e}")
        print("You can still watch the camera feed; press ESC in the feed window to exit.")
        tracker.join()
        return

    print("\nReady. Use teleop keys to move; press X to record an example.")
    print("Tip: leave the instruction BLANK to auto-generate a small batch for the chosen cell.\n")

    # 3) Define what happens on 'x' (record)
    def on_record():
        # --- Read current robot state once (used for all samples in this click) ---
        try:
            tcp_pose     = [float(x) for x in list(robot.get_actual_tcp_pose())]
            joint_angles = [float(q) for q in list(robot.get_actual_joint_positions())]
        except Exception as e:
            print(f"Pose read failed: {e}")
            return

        # --- Get/confirm the target cell (auto from tracker, or manual override) ---
        detected = tracker.get_latest_cell()
        print(f"Detected cell: {detected if detected else 'None'}")
        manual = input(f"Enter target cell to use (Enter = keep detected): ").strip()
        target_cell = normalize_cell(manual) if manual else normalize_cell(detected)
        if not target_cell:
            # require explicit entry if nothing valid
            while True:
                manual2 = input("Please type a valid cell (e.g., A1..J14): ").strip()
                target_cell = normalize_cell(manual2)
                if target_cell:
                    break

        # --- Instruction: one-off or batch auto? ---
        instr = input("Instruction (leave BLANK to auto-generate a small batch): ").strip()

        if instr:
            # Single sample (original behavior)
            example = {
                "instruction": instr,
                "tcp_pose": tcp_pose,             # [x,y,z,rx,ry,rz]
                "joint_angles": joint_angles,     # [q0..q5]
                "target_cell": target_cell
            }
            append_example(OUTPUT_PATH, example)
            print(f"Saved (1): {example}")
        else:
            # Batch auto-generate from templates (minimal automation)
            made = 0
            for tmpl in TEMPLATES:
                gen = tmpl.replace("{CELL}", target_cell)
                example = {
                    "instruction": gen,
                    "tcp_pose": tcp_pose,
                    "joint_angles": joint_angles,
                    "target_cell": target_cell
                }
                append_example(OUTPUT_PATH, example)
                made += 1
            print(f"Saved batch ({made}) for {target_cell}.")
        # --- end on_record ---

    # 4) Hand over to teleop loop (movement + record trigger)
    try:
        teleop.run_teleop(robot, tracker, on_record)
    finally:
        try:
            robot.close()
        except Exception:
            pass
        print("\nTeleop ended. Camera feed is STILL RUNNING.")
        print("➡ Press ESC in the camera window to close it and exit.")
        tracker.join()  # keep feed on until ESC

if __name__ == "__main__":
    main()
