#!/usr/bin/env python3
# build_dataset_onepass.py
# One-pass pipeline: paraphrase -> composition -> dedup -> verify -> rebalance -> final JSONL

import argparse, json, math, random, re, ast, csv
from pathlib import Path
from typing import List, Dict, Tuple

# --------------------------- Limits & Defaults ---------------------------

MAX_MM  = 20.0   # translation limit (mm)
MAX_DEG = 10.0   # rotation limit (deg)

DEFAULT_MM_STEPS  = [5, 10, 15, 20]
DEFAULT_DEG_STEPS = [2, 5, 10]

ACC_DEFAULT = 0.4
VEL_DEFAULT = 0.2
IP_DEFAULT  = "192.168.1.100"

# Target mix after rebalancing (approximate)
PCT_BASE_DEFAULT = 0.50
PCT_COMP_DEFAULT = 0.25
PCT_PARA_DEFAULT = 0.25

# --------------------------- Regex & Maps ---------------------------

RE_MM_CODE  = re.compile(r'\b(DX|DY|DZ)\s*=\s*([0-9]*\.?[0-9]+)')   # metres in code
RE_DEG_CODE = re.compile(r'\bDTH\s*=\s*([0-9\-\+]*\.?[0-9]+)\s*\*\s*math\.pi\s*/\s*180')
RE_AXIS_IDX = re.compile(r'p\[(?P<idx>[0-5])\]\s*\+\=')
RE_CELL     = re.compile(r'\b(?:Centre|Center)\s+on\s+([A-Z]\d{1,2})\.?', re.IGNORECASE)

IDX2AXIS = {0:"x",1:"y",2:"z",3:"rx",4:"ry",5:"rz"}
AXIS_WORD = {"x":"X","y":"Y","z":"Z"}
AXL_NAME  = {"rx":"Rx","ry":"Ry","rz":"Rz"}
EULER     = {"rx":"Roll","ry":"Pitch","rz":"Yaw"}

TRANSLATION_TEMPLATES = [
    "Nudge {sign}{mm} millimetres along {axis}.",
    "Move {sign}{mm} mm in {axis}.",
    "Shift {sign}{mm} mm on the {axis}-axis.",
    "Step {sign}{mm} mm along {axis}.",
    "Displace {sign}{mm} mm along {axis}."
]
TRANSLATION_TEMPLATES_CM = [
    "Move {sign}{cm} centimetres on the {axis}-axis.",
    "Shift {sign}{cm} cm in {axis}.",
]
ROTATION_TEMPLATES = [
    "Rotate {sign}{deg} degrees about {axl}.",
    "Turn {sign}{deg}° around {axl}.",
    "{euler} by {sign}{deg} degrees.",
    "Apply {sign}{deg}° about {axl}."
]
CHARUCO_TEMPLATES = [
    "Centre on {cell}.",
    "Center on {cell}.",
    "Move to cell {cell}.",
    "Align to {cell}.",
    "Go to {cell}."
]
ABSPOSE_TEMPLATES = [
    "Move the TCP to the specified pose.",
    "Go to the given Cartesian pose.",
    "Move to this pose and stop.",
]

# --------------------------- Utils ---------------------------

def load_jsonl(path: Path) -> List[Dict]:
    rows = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line: continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                continue
            if "instruction" in obj and "output_code" in obj:
                rows.append(obj)
    return rows

def write_jsonl(path: Path, rows: List[Dict]):
    with path.open("w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")

def dedup(rows: List[Dict]) -> List[Dict]:
    seen = set(); out = []
    for r in rows:
        instr = r.get("instruction","").strip().lower()
        code  = r.get("output_code","").strip()
        key = (instr, code)
        if key in seen: 
            continue
        seen.add(key); out.append(r)
    return out

def metres_to_mm(m: float) -> float:
    return round(m * 1000.0, 6)

def mm_to_cm_str(mm: float) -> str:
    cm = mm / 10.0
    s = f"{cm:.2f}".rstrip("0").rstrip(".")
    return s

def sign_str(v: float) -> str:
    return "+" if v >= 0 else "-"

def round_if_int(x: float):
    rx = round(x)
    return int(rx) if abs(x - rx) < 1e-9 else x

# --------------------------- Classification ---------------------------

def detect_axis_from_code(code: str) -> str|None:
    m = RE_AXIS_IDX.search(code)
    if m:
        idx = int(m.group("idx"))
        return IDX2AXIS.get(idx)
    if "DX" in code: return "x"
    if "DY" in code: return "y"
    if "DZ" in code: return "z"
    if "DTH" in code and "p[3]+=" in code: return "rx"
    if "DTH" in code and "p[4]+=" in code: return "ry"
    if "DTH" in code and "p[5]+=" in code: return "rz"
    return None

def classify_row(code: str) -> str:
    if "cell_to_pose(" in code: return "charuco_abs"
    if "pose=[" in code and "robot.movel(pose" in code: return "abs_pose"
    if RE_MM_CODE.search(code): return "rel_translate"
    if RE_DEG_CODE.search(code): return "rel_rotate"
    return "other"

# --------------------------- Paraphrase Expansion ---------------------------

def make_paraphrases(row: Dict, variants: int, rng: random.Random) -> List[str]:
    instr = row["instruction"]
    code  = row["output_code"]
    kind  = classify_row(code)
    axis  = detect_axis_from_code(code)

    outs: List[str] = []

    if kind == "rel_translate" and axis in {"x","y","z"}:
        m = RE_MM_CODE.search(code)
        metres = float(m.group(2))
        mm = metres_to_mm(metres)
        sgn = sign_str(mm)
        mm_abs = abs(mm)
        axis_name = AXIS_WORD[axis]
        tmpls = rng.sample(TRANSLATION_TEMPLATES, min(variants, len(TRANSLATION_TEMPLATES)))
        for t in tmpls:
            outs.append(t.format(sign=sgn, mm=round_if_int(mm_abs), axis=axis_name))
        # optional cm variant
        if mm_abs % 5 == 0 and len(outs) < variants and rng.random() < 0.7:
            t = rng.choice(TRANSLATION_TEMPLATES_CM)
            outs.append(t.format(sign=sgn, cm=mm_to_cm_str(mm_abs), axis=axis_name))

    elif kind == "rel_rotate" and axis in {"rx","ry","rz"}:
        m = RE_DEG_CODE.search(code)
        deg = float(m.group(1))
        sgn = sign_str(deg)
        dabs = abs(deg)
        axl  = AXL_NAME[axis]
        eul  = EULER[axis]
        tmpls = rng.sample(ROTATION_TEMPLATES, min(variants, len(ROTATION_TEMPLATES)))
        for t in tmpls:
            outs.append(t.format(sign=sgn, deg=round_if_int(dabs), axl=axl, euler=eul))

    elif kind == "charuco_abs":
        cm = RE_CELL.search(instr)
        cell = cm.group(1) if cm else None
        if not cell: return []
        tmpls = rng.sample(CHARUCO_TEMPLATES, min(variants, len(CHARUCO_TEMPLATES)))
        for t in tmpls:
            outs.append(t.format(cell=cell))

    elif kind == "abs_pose":
        tmpls = rng.sample(ABSPOSE_TEMPLATES, min(variants, len(ABSPOSE_TEMPLATES)))
        outs.extend(tmpls)

    # drop duplicates and original
    base_norm = instr.strip().lower()
    uniq = []
    seen = {base_norm}
    for p in outs:
        q = p.strip()
        if not q: continue
        if q.lower() in seen: continue
        seen.add(q.lower()); uniq.append(q)
    return uniq

def expand_paraphrases(base_rows: List[Dict], per_row: int, seed: int) -> List[Dict]:
    rng = random.Random(seed)
    out = []
    for r in base_rows:
        out.append(r | {"_source":"base"})
    for r in base_rows:
        paras = make_paraphrases(r, per_row, rng)
        for p in paras:
            out.append({
                "instruction": p,
                "tags": r.get("tags", []),
                "output_code": r["output_code"],
                "_source": "paraphrase"
            })
    return out

# --------------------------- Composition Generation ---------------------------

def code_header(ip, acc, vel, need_math=False):
    imp = "import math, URBasic" if need_math else "import URBasic"
    return (
f"{imp}\nACCELERATION={acc}; VELOCITY={vel}\n"
f"model=URBasic.robotModel.RobotModel()\n"
f"robot=URBasic.urScriptExt.UrScriptExt(host='{ip}', robotModel=model)\n"
"try:\n"
"    robot.reset_error()\n"
)

def code_footer():
    return "finally:\n    robot.close()\n"

def code_step_linear(axis, mm):
    idx = {"x":0,"y":1,"z":2}[axis]
    m  = mm/1000.0
    return (
f"    p=list(robot.get_actual_tcp_pose())\n"
f"    p[{idx}]+={m:.3f}\n"
f"    robot.movel(p, a=ACCELERATION, v=VELOCITY)\n"
)

def code_step_rotate(axis, deg):
    idx = {"rx":3,"ry":4,"rz":5}[axis]
    return (
f"    p=list(robot.get_actual_tcp_pose())\n"
f"    p[{idx}]+={deg:.6f}*math.pi/180\n"
f"    robot.movel(p, a=ACCELERATION, v=VELOCITY)\n"
)

def make_instruction_linear(axis, mm):
    s = "+" if mm>=0 else "-"
    return f"Nudge {s}{int(abs(mm))} millimetres along {AXIS_WORD[axis]}."

def make_instruction_rotate(axis, deg):
    s = "+" if deg>=0 else "-"
    return f"Rotate {s}{int(abs(deg))} degrees about {AXL_NAME[axis]}."

def generate_compositions(ip, acc, vel, mm_steps, deg_steps, limit, seed):
    rng = random.Random(seed)
    AXES_LIN = ("x","y","z")
    AXES_ROT = ("rx","ry","rz")
    rows = []
    combos = []
    for r_axis in AXES_ROT:
        for r_mag in deg_steps:
            r_mag = min(MAX_DEG, abs(float(r_mag)))
            for r_sign in (+1,-1):
                for l_axis in AXES_LIN:
                    for l_mag in mm_steps:
                        l_mag = min(MAX_MM, abs(float(l_mag)))
                        for l_sign in (+1,-1):
                            combos.append( (("rot", r_axis, r_sign*r_mag), ("lin", l_axis, l_sign*l_mag)) )
                            combos.append( (("lin", l_axis, l_sign*l_mag), ("rot", r_axis, r_sign*r_mag)) )
    rng.shuffle(combos)
    for (t1, a1, m1), (t2, a2, m2) in combos[:limit]:
        need_math = (t1=="rot") or (t2=="rot")
        code = code_header(ip, acc, vel, need_math=need_math)
        instr_parts = []
        if t1=="lin":
            instr_parts.append(make_instruction_linear(a1, m1))
            code += code_step_linear(a1, m1)
        else:
            instr_parts.append(make_instruction_rotate(a1, m1))
            code += code_step_rotate(a1, m1)
        if t2=="lin":
            instr_parts.append(make_instruction_linear(a2, m2))
            code += code_step_linear(a2, m2)
        else:
            instr_parts.append(make_instruction_rotate(a2, m2))
            code += code_step_rotate(a2, m2)
        code += code_footer()
        instruction = instr_parts[0].rstrip(".") + ", then " + instr_parts[1][0].lower() + instr_parts[1][1:]
        rows.append({
            "instruction": instruction,
            "tags": ["composition","rel_move","movel"],
            "output_code": code,
            "_source": "composition"
        })
    return rows

# --------------------------- Static Verifier ---------------------------

def code_movel_count(tree: ast.AST) -> int:
    class Visitor(ast.NodeVisitor):
        def __init__(self): self.calls=0
        def visit_Call(self, node):
            try:
                if isinstance(node.func, ast.Attribute) and node.func.attr == "movel":
                    self.calls += 1
            except: pass
            self.generic_visit(node)
    v=Visitor(); v.visit(tree)
    return v.calls

def check_relative_translation(code: str) -> Tuple[bool,str]:
    m = RE_MM_CODE.search(code)
    if not m: return (False, "no DX/DY/DZ")
    metres = float(m.group(2))
    mm = metres * 1000.0
    if abs(mm) > MAX_MM + 1e-6:
        return (False, f"translation {mm:.3f} mm exceeds limit")
    m2 = RE_AXIS_IDX.search(code)
    if not m2: return (False, "no p[index]+=")
    idx = int(m2.group("idx"))
    if idx not in (0,1,2): return (False, f"bad index {idx}")
    return (True, "ok")

def check_relative_rotation(code: str) -> Tuple[bool,str]:
    m = RE_DEG_CODE.search(code)
    if not m: return (False, "no DTH")
    deg = float(m.group(1))
    if abs(deg) > MAX_DEG + 1e-6:
        return (False, f"rotation {deg:.3f} deg exceeds limit")
    m2 = RE_AXIS_IDX.search(code)
    if not m2: return (False, "no p[index]+=")
    idx = int(m2.group("idx"))
    if idx not in (3,4,5): return (False, f"bad rot index {idx}")
    return (True, "ok")

def classify_kind(code: str) -> str:
    if "cell_to_pose(" in code: return "charuco_abs"
    if "pose=[" in code and "robot.movel(pose" in code: return "abs_pose"
    if RE_MM_CODE.search(code): return "rel_trans"
    if RE_DEG_CODE.search(code): return "rel_rot"
    return "unknown"

def verify_rows(rows: List[Dict], report_csv: Path|None=None) -> List[Dict]:
    kept = []
    report_data = []
    for i, row in enumerate(rows, 1):
        code = row.get("output_code","")
        try:
            tree = ast.parse(code)
        except SyntaxError as e:
            report_data.append((i, "syntax_error", str(e))); continue
        movel_cnt = code_movel_count(tree)
        kind = classify_kind(code)

        ok=True; reason="ok"
        if kind=="rel_trans":
            ok, reason = check_relative_translation(code)
            if ok and movel_cnt<1: ok, reason=False, "no movel"
        elif kind=="rel_rot":
            ok, reason = check_relative_rotation(code)
            if ok and movel_cnt<1: ok, reason=False, "no movel"
        elif kind in ("abs_pose","charuco_abs"):
            ok = movel_cnt>=1
            reason = "ok" if ok else "no movel in absolute move"
        else:
            ok = movel_cnt>=1
            reason = "ok" if ok else "unknown_no_movel"

        if ok:
            kept.append(row)
            report_data.append((i, kind, "kept"))
        else:
            report_data.append((i, kind, f"drop:{reason}"))

    if report_csv:
        with report_csv.open("w", newline="", encoding="utf-8") as f:
            w=csv.writer(f); w.writerow(["row_idx","kind","status"])
            w.writerows(report_data)

    return kept

# --------------------------- Rebalancing ---------------------------

def rebalance(rows: List[Dict], pct_base: float, pct_comp: float, pct_para: float, seed: int) -> List[Dict]:
    rng = random.Random(seed)
    base = [r for r in rows if r.get("_source") == "base"]
    comp = [r for r in rows if r.get("_source") == "composition"]
    para = [r for r in rows if r.get("_source") == "paraphrase"]

    B = len(base); C = len(comp); P = len(para)
    if B == 0:
        # if somehow no base survived verification, just return everything deduped
        return rows

    # Desired counts given B as anchor
    goal_para = int(round(B * (pct_para / max(pct_base, 1e-9))))
    goal_comp = int(round(B * (pct_comp / max(pct_base, 1e-9))))

    # Cap by availability
    keep_para = min(P, goal_para)
    keep_comp = min(C, goal_comp)

    rng.shuffle(para); rng.shuffle(comp)
    selected = base + para[:keep_para] + comp[:keep_comp]
    # Final dedup (drop _source in output)
    selected = dedup(selected)
    for r in selected: r.pop("_source", None)
    return selected

# --------------------------- Main ---------------------------

def main():
    ap = argparse.ArgumentParser(description="One-pass dataset builder for NL→Python(URBasic).")
    ap.add_argument("--base", type=Path, required=True, help="Input base JSONL (instruction,tags,output_code)")
    ap.add_argument("--outfile", type=Path, default=Path("llm_urbasic_final.jsonl"))

    # paraphrases
    ap.add_argument("--per_row", type=int, default=2, help="paraphrases per eligible row (code unchanged)")
    ap.add_argument("--para_seed", type=int, default=7)

    # compositions
    ap.add_argument("--comp_limit", type=int, default=200, help="max composition rows to generate")
    ap.add_argument("--mm",  type=str, default=",".join(map(str, DEFAULT_MM_STEPS)))
    ap.add_argument("--deg", type=str, default=",".join(map(str, DEFAULT_DEG_STEPS)))
    ap.add_argument("--ip", default=IP_DEFAULT)
    ap.add_argument("--acc", type=float, default=ACC_DEFAULT)
    ap.add_argument("--vel", type=float, default=VEL_DEFAULT)
    ap.add_argument("--comp_seed", type=int, default=11)

    # verification
    ap.add_argument("--report", type=Path, default=Path("verification_report.csv"))

    # rebalance ratios
    ap.add_argument("--pct_base", type=float, default=PCT_BASE_DEFAULT)
    ap.add_argument("--pct_comp", type=float, default=PCT_COMP_DEFAULT)
    ap.add_argument("--pct_para", type=float, default=PCT_PARA_DEFAULT)
    ap.add_argument("--rebalance_seed", type=int, default=42)

    args = ap.parse_args()

    # Load base
    base_rows = load_jsonl(args.base)
    if not base_rows:
        print(f"[!] No rows loaded from {args.base}")
        return

    # Paraphrases
    merged = expand_paraphrases(base_rows, args.per_row, args.para_seed)

    # Compositions
    mm_steps  = [min(MAX_MM, abs(float(x))) for x in args.mm.split(",") if x.strip()]
    deg_steps = [min(MAX_DEG, abs(float(x))) for x in args.deg.split(",") if x.strip()]
    comps = generate_compositions(args.ip, args.acc, args.vel, mm_steps, deg_steps, args.comp_limit, args.comp_seed)
    merged.extend(comps)

    # Dedup before verify (keep earliest, preserves 'base' preference)
    merged = dedup(merged)

    # Verify safety/shape
    verified = verify_rows(merged, report_csv=args.report)

    # Rebalance by source
    final_rows = rebalance(verified, args.pct_base, args.pct_comp, args.pct_para, args.rebalance_seed)

    # Write final
    write_jsonl(args.outfile, final_rows)

    # Print summary
    total_base = sum(1 for r in verified if r.get("_source")=="base")
    total_para = sum(1 for r in verified if r.get("_source")=="paraphrase")
    total_comp = sum(1 for r in verified if r.get("_source")=="composition")
    print(f"Loaded base: {len(base_rows)}")
    print(f"After paraphrase+composition merge (dedup): {len(merged)}")
    print(f"Verified kept: {len(verified)} (base={total_base}, para={total_para}, comp={total_comp})")
    print(f"Wrote final: {len(final_rows)} -> {args.outfile}")
    print(f"Verification report: {args.report}")

if __name__ == "__main__":
    main()
