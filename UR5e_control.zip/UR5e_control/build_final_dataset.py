#!/usr/bin/env python3
# build_final_dataset.py
# Merge existing instruction→code data with generated relative moves/rotations
# and write llm_urbasic_dataset_final.jsonl

import argparse, json, math, random
from pathlib import Path

# --------------------------- limits & defaults ---------------------------

MAX_MM  = 20.0     # laparoscopic translation limit (mm)
MAX_DEG = 10.0     # laparoscopic rotation limit (deg)

DEFAULT_MM_STEPS  = [5, 10, 15, 20]   # mm
DEFAULT_DEG_STEPS = [2, 5, 10]        # degrees

ACC_DEFAULT = 0.4
VEL_DEFAULT = 0.2
IP_DEFAULT  = "192.168.1.100"

TRANSLATION_SYNS = [
    "Nudge {sign}{mag} millimetres along {axis}.",
    "Move {sign}{mag} mm in {axis}.",
    "Shift {sign}{mag} mm on the {axis}-axis.",
    "Step {sign}{mag} mm along {axis}."
]
ROTATION_SYNS = [
    "Rotate {sign}{deg} degrees about {axl}.",
    "Turn {sign}{deg} degrees around {axl}.",
    "{name} by {sign}{deg} degrees."
]

AXIS_WORD = {"x": "X", "y": "Y", "z": "Z"}
AXL_NAME  = {"rx": "Rx", "ry": "Ry", "rz": "Rz"}
EULER_NAME= {"rx": "Roll", "ry": "Pitch", "rz": "Yaw"}
IDX       = {"x":0,"y":1,"z":2,"rx":3,"ry":4,"rz":5}

# --------------------------- helpers ---------------------------

def clamp_unique_mags(values, max_abs):
    """Return unique absolute magnitudes (preserve order), clamped to max_abs."""
    out = []
    seen = set()
    for v in values:
        v = float(v)
        if abs(v) > max_abs:
            v = max_abs if v > 0 else -max_abs
        a = abs(v)
        if a not in seen:
            seen.add(a)
            out.append(a)
    return out

def choose_synonyms(syn_list, k, rng):
    if k >= len(syn_list): return syn_list[:]
    return rng.sample(syn_list, k)

def code_for_translation(axis, mm, ip, acc, vel):
    var = {"x":"DX","y":"DY","z":"DZ"}[axis]
    idx = IDX[axis]
    mm_m = mm / 1000.0
    return (
f"import URBasic\n"
f"ACCELERATION={acc}; VELOCITY={vel}; {var}={mm_m:.3f}\n"
f"model=URBasic.robotModel.RobotModel()\n"
f"robot=URBasic.urScriptExt.UrScriptExt(host='{ip}', robotModel=model)\n"
"try:\n"
"    robot.reset_error()\n"
"    p=list(robot.get_actual_tcp_pose())\n"
f"    p[{idx}]+={var}\n"
"    robot.movel(p, a=ACCELERATION, v=VELOCITY)\n"
"finally:\n"
"    robot.close()\n"
    )

def code_for_rotation(axl, deg, ip, acc, vel):
    idx = IDX[axl]
    return (
f"import math, URBasic\n"
f"ACCELERATION={acc}; VELOCITY={vel}; DTH={deg:.6f}*math.pi/180\n"
f"model=URBasic.robotModel.RobotModel()\n"
f"robot=URBasic.urScriptExt.UrScriptExt(host='{ip}', robotModel=model)\n"
"try:\n"
"    robot.reset_error()\n"
"    p=list(robot.get_actual_tcp_pose())\n"
f"    p[{idx}]+=DTH\n"
"    robot.movel(p, a=ACCELERATION, v=VELOCITY)\n"
"finally:\n"
"    robot.close()\n"
    )

def make_translation_rows(mm_steps, variants, ip, acc, vel, rng):
    rows = []
    for axis in ("x","y","z"):
        for mag in mm_steps:
            for sign in (+1,-1):
                sign_str = "+" if sign > 0 else "-"
                for tmpl in choose_synonyms(TRANSLATION_SYNS, variants, rng):
                    instr = tmpl.format(sign=sign_str, mag=int(mag), axis=AXIS_WORD[axis])
                    code  = code_for_translation(axis, sign*mag, ip, acc, vel)
                    rows.append({
                        "instruction": instr,
                        "tags": ["rel_move","movel", f"axis_{axis}"],
                        "output_code": code
                    })
    return rows

def make_rotation_rows(deg_steps, variants, ip, acc, vel, rng):
    rows = []
    for axl in ("rx","ry","rz"):
        for mag in deg_steps:
            for sign in (+1,-1):
                sign_str = "+" if sign > 0 else "-"
                for tmpl in choose_synonyms(ROTATION_SYNS, variants, rng):
                    instr = tmpl.format(sign=sign_str, deg=int(mag), axl=AXL_NAME[axl], name=EULER_NAME[axl])
                    code  = code_for_rotation(axl, sign*mag, ip, acc, vel)
                    rows.append({
                        "instruction": instr,
                        "tags": ["rotate","rel_move","movel", f"axis_{axl}"],
                        "output_code": code
                    })
    return rows

def load_jsonl(path: Path):
    rows = []
    with path.open("r", encoding="utf-8") as f:
        for i, line in enumerate(f, 1):
            line = line.strip()
            if not line: 
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                # skip malformed lines
                continue
            # minimal validation
            if "instruction" in obj and "output_code" in obj:
                rows.append(obj)
    return rows

def dedup(rows):
    seen = set()
    out  = []
    for r in rows:
        instr = r.get("instruction","").strip()
        code  = r.get("output_code","").strip()
        key = (instr, code)
        if key in seen: 
            continue
        seen.add(key)
        out.append(r)
    return out

# --------------------------- main ---------------------------

def main():
    ap = argparse.ArgumentParser(description="Merge existing dataset with generated relative moves/rotations.")
    ap.add_argument("--base", type=Path, required=True, help="Path to llm_urbasic_code_sft.jsonl")
    ap.add_argument("--outfile", type=Path, default=Path("llm_urbasic_dataset_final.jsonl"))
    ap.add_argument("--ip", default=IP_DEFAULT)
    ap.add_argument("--acc", type=float, default=ACC_DEFAULT)
    ap.add_argument("--vel", type=float, default=VEL_DEFAULT)
    ap.add_argument("--mm",  type=str, default=",".join(map(str, DEFAULT_MM_STEPS)),
                    help="comma-separated magnitudes in mm (abs), will be clamped ≤20")
    ap.add_argument("--deg", type=str, default=",".join(map(str, DEFAULT_DEG_STEPS)),
                    help="comma-separated magnitudes in degrees (abs), will be clamped ≤10")
    ap.add_argument("--variants", type=int, default=2, help="phrasing variants per (axis,mag,sign)")
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    rng = random.Random(args.seed)

    # Load existing data
    base_rows = load_jsonl(args.base)
    base_rows = dedup(base_rows)

    # Parse and clamp magnitudes
    mm_steps  = clamp_unique_mags([float(x) for x in args.mm.split(",") if x.strip()], MAX_MM)
    deg_steps = clamp_unique_mags([float(x) for x in args.deg.split(",") if x.strip()], MAX_DEG)

    # Generate new data within constraints
    new_rows  = []
    new_rows += make_translation_rows(mm_steps, args.variants, args.ip, args.acc, args.vel, rng)
    new_rows += make_rotation_rows(deg_steps,  args.variants, args.ip, args.acc, args.vel, rng)

    # Merge + dedup
    combined = dedup(base_rows + new_rows)

    # Write
    with args.outfile.open("w", encoding="utf-8") as f:
        for r in combined:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")

    print(f"Base rows: {len(base_rows)}")
    print(f"New rows:  {len(new_rows)} (pre-dedup)")
    print(f"Wrote:     {len(combined)} -> {args.outfile}")

if __name__ == "__main__":
    main()
