# C:\Users\hitis\Desktop\UR5e_control\charuco_center_cell.py
# Reusable center-cell tracker (PDF registration, no aruco).
# Window stays on until you press ESC in the camera window or call stop().

import os
import time
import threading
import cv2
import fitz  # PyMuPDF
import numpy as np
from typing import Callable, Optional

from charuco_read import build_cell_map, SQUARES_X, SQUARES_Y

PDF_PATH_DEFAULT = r"C:\Users\hitis\Desktop\UR5e_control\ChArUco__A4.pdf"

class CenterCellTracker:
    def __init__(
        self,
        pdf_path: str = PDF_PATH_DEFAULT,
        cam_index: int = 0,
        min_matches: int = 40,
        ratio: float = 0.75,
        visualize: bool = True,
        verbose: bool = False,
    ):
        self.pdf_path = pdf_path
        self.cam_index = cam_index
        self.min_matches = min_matches
        self.ratio = ratio
        self.visualize = visualize
        self.verbose = verbose

        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._callback: Optional[Callable[[str], None]] = None
        self._latest_cell: Optional[str] = None

        # Prepared reference items
        self._H_roi_to_grid = None
        self._kp_ref = None
        self._des_ref = None
        self._bf = None
        self._orb = None

        # Name map
        name_map = build_cell_map()
        self._top0_to_name = {(v["row_index_top0"], v["col_index_left0"]): k for k, v in name_map.items()}

        self._prepare_reference()

    @staticmethod
    def _render_pdf_first_page(pdf_path: str, dpi: int = 300) -> np.ndarray:
        doc = fitz.open(pdf_path)
        page = doc.load_page(0)
        zoom = dpi / 72.0
        mat = fitz.Matrix(zoom, zoom)
        pix = page.get_pixmap(matrix=mat, alpha=False)
        img = np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.h, pix.w, 3)
        img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
        doc.close()
        return img

    @staticmethod
    def _order_pts(pts):
        rect = np.zeros((4, 2), dtype="float32")
        s = pts.sum(axis=1)
        rect[0] = pts[np.argmin(s)]     # TL
        rect[2] = pts[np.argmax(s)]     # BR
        diff = np.diff(pts, axis=1)
        rect[1] = pts[np.argmin(diff)]  # TR
        rect[3] = pts[np.argmax(diff)]  # BL
        return rect

    def _find_board_quad(self, img_bgr: np.ndarray) -> np.ndarray:
        gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
        gray = cv2.equalizeHist(gray)
        thr = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                    cv2.THRESH_BINARY_INV, 51, 5)
        k = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5))
        thr = cv2.morphologyEx(thr, cv2.MORPH_CLOSE, k, iterations=2)
        cnts, _ = cv2.findContours(thr, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not cnts:
            raise RuntimeError("PDF: no contours found.")
        cnts = sorted(cnts, key=cv2.contourArea, reverse=True)
        for c in cnts[:10]:
            peri = cv2.arcLength(c, True)
            approx = cv2.approxPolyDP(c, 0.02 * peri, True)
            if len(approx) == 4 and cv2.isContourConvex(approx):
                return self._order_pts(approx.reshape(-1, 2).astype(np.float32))
        raise RuntimeError("PDF: failed to detect rectangular board area.")

    def _prepare_reference(self):
        ref_img = self._render_pdf_first_page(self.pdf_path, dpi=300)
        quad_ref = self._find_board_quad(ref_img)
        x_min = int(min(quad_ref[:, 0])); x_max = int(max(quad_ref[:, 0]))
        y_min = int(min(quad_ref[:, 1])); y_max = int(max(quad_ref[:, 1]))
        roi_ref = ref_img[y_min:y_max, x_min:x_max].copy()
        quad_in_roi = quad_ref - np.array([x_min, y_min], dtype=np.float32)

        dst_grid = np.array([[0, 0],
                             [SQUARES_X, 0],
                             [SQUARES_X, SQUARES_Y],
                             [0, SQUARES_Y]], dtype=np.float32)
        self._H_roi_to_grid = cv2.getPerspectiveTransform(quad_in_roi, dst_grid)

        self._orb = cv2.ORB_create(nfeatures=4000)
        roi_gray = cv2.cvtColor(roi_ref, cv2.COLOR_BGR2GRAY)
        self._kp_ref, self._des_ref = self._orb.detectAndCompute(roi_gray, None)
        self._bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=False)

    # ---------------- Public API ----------------
    def start(self, callback: Optional[Callable[[str], None]] = None):
        """Begin camera tracking. Calls callback(cell_name) when the centre cell changes."""
        self._callback = callback
        self._stop.clear()
        # Non-daemon -> persists until you press ESC or call stop()
        self._thread = threading.Thread(target=self._run, daemon=False)
        self._thread.start()

    def stop(self, wait: bool = True):
        """Stop the camera thread."""
        self._stop.set()
        if wait and self._thread is not None:
            self._thread.join(timeout=2.0)

    def join(self):
        """Block until the camera thread exits (e.g., after ESC or stop())."""
        if self._thread is not None:
            self._thread.join()

    def get_latest_cell(self) -> Optional[str]:
        return self._latest_cell

    # ---------------- Internal loop ----------------
    def _run(self):
        cap = cv2.VideoCapture(self.cam_index)
        if not cap.isOpened():
            if self.verbose:
                print("[CenterCellTracker] Cannot open camera.")
            return

        win = "Center Cell (PDF-registered)"
        last_cell = None
        while not self._stop.is_set():
            ok, frame = cap.read()
            if not ok:
                if self.verbose:
                    print("[CenterCellTracker] Frame grab failed.")
                break

            h, w = frame.shape[:2]
            cx, cy = w // 2, h // 2

            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            kp_frm, des_frm = self._orb.detectAndCompute(gray, None)

            cell_name = None
            if des_frm is not None and self._des_ref is not None and len(kp_frm) > 0 and len(self._kp_ref) > 0:
                matches = self._bf.knnMatch(self._des_ref, des_frm, k=2)
                good = [m for m, n in matches if m.distance < self.ratio * n.distance] if len(matches) else []
                if len(good) >= self.min_matches:
                    src = np.float32([kp_frm[m.trainIdx].pt for m in good]).reshape(-1, 1, 2)
                    dst = np.float32([self._kp_ref[m.queryIdx].pt for m in good]).reshape(-1, 1, 2)
                    H_frame_to_roi, _ = cv2.findHomography(src, dst, cv2.RANSAC, 4.0)
                    if H_frame_to_roi is not None:
                        H_frame_to_grid = self._H_roi_to_grid @ H_frame_to_roi
                        pt = np.array([[[cx, cy]]], dtype=np.float32)
                        grid_pt = cv2.perspectiveTransform(pt, H_frame_to_grid)[0, 0]
                        u, v = float(grid_pt[0]), float(grid_pt[1])
                        col = int(np.floor(u))
                        row_top0 = int(np.floor(v))
                        if 0 <= col < SQUARES_X and 0 <= row_top0 < SQUARES_Y:
                            cell_name = self._top0_to_name.get((row_top0, col))

            if self.visualize:
                cv2.drawMarker(frame, (cx, cy), (0, 255, 0), cv2.MARKER_CROSS, 20, 2)
                label = f"Center: {cell_name}" if cell_name else "Center: (no board)"
                cv2.putText(frame, label, (20, 40), cv2.FONT_HERSHEY_SIMPLEX, 1.0,
                            (50, 220, 50) if cell_name else (0, 0, 255), 2)
                cv2.imshow(win, frame)
                key = cv2.waitKey(1) & 0xFF
                if key == 27:  # ESC explicitly closes the feed
                    self._stop.set()
                    break

            if cell_name and cell_name != last_cell:
                self._latest_cell = cell_name
                if self._callback:
                    try:
                        self._callback(cell_name)
                    except Exception:
                        pass
                last_cell = cell_name

        cap.release()
        if self.visualize:
            try:
                cv2.destroyWindow(win)
            except Exception:
                pass

# Optional standalone run
if __name__ == "__main__":
    def _print_update(cell):
        print("Center cell:", cell)
    tracker = CenterCellTracker(visualize=True, verbose=True)
    tracker.start(callback=_print_update)
    tracker.join()  # keep running until ESC
