import time
import sys
import os
import math3d as m3d
import URBasic
import cv2
from URBasic.kinematic import Invkine_manip, Forwardkin_manip
from contextlib import contextmanager
import io

"""The termios, tty and select modules are only available on POSIX systems.
On Windows we will instead use msvcrt for key detection.  The imports
are therefore deferred based on the operating system to prevent
ImportError on Windows."""
if os.name != 'nt':
    import select  # POSIX only
    import termios
    import tty
else:
    import msvcrt  # Windows only


# ---------- Configuration ----------
ROBOT_IP = "192.168.1.100"  # IP address of the UR5e controller
ACCELERATION = 0.4           # Tool acceleration [m/s²]
VELOCITY = 0.2               # Tool velocity [m/s]
STEP_SIZE = 0.01             # Position step for each key press [m]
STEP_ROT = 0.05              # Rotational step size in radians (~2.86 degrees)


@contextmanager
def raw_mode(fileobj):
    """Context manager that puts the terminal into raw mode when possible."""
    if os.name != 'nt' and fileobj is not None:
        orig_attrs = termios.tcgetattr(fileobj)
        tty.setcbreak(fileobj)
        try:
            yield
        finally:
            termios.tcsetattr(fileobj, termios.TCSADRAIN, orig_attrs)
    else:
        yield


def get_key(timeout=0.0):
    """Cross‑platform non‑blocking key press reader."""
    if os.name == 'nt':
        if msvcrt.kbhit():
            return msvcrt.getwch()
        else:
            time.sleep(timeout)
            return None
    else:
        dr, dw, de = select.select([sys.stdin], [], [], timeout)
        if dr:
            return sys.stdin.read(1)
        return None


def connect_robot():
    """Attempt to connect to the UR5e and return a handle."""
    print(f"Connecting to robot at {ROBOT_IP} …")
    model = URBasic.robotModel.RobotModel()
    robot = URBasic.urScriptExt.UrScriptExt(host=ROBOT_IP, robotModel=model)
    robot.reset_error()
    return robot


# The sanity_move function has been removed to streamline the workflow.  The
# robot no longer performs a preliminary joint motion before teleoperation.


def select_object_from_camera():
    """Prompt user to select an object from the camera feed."""
    cap = cv2.VideoCapture(0)  # Change index if needed for your camera
    if not cap.isOpened():
        print("Could not open camera.")
        return None
    
    print("Press SPACE to capture the frame for object selection.")
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        cv2.imshow("Camera Feed - Press SPACE to capture", frame)
        key = cv2.waitKey(1) & 0xFF
        if key == 32:  # Spacebar
            break
        elif key == 27:  # ESC to quit
            cap.release()
            cv2.destroyAllWindows()
            return None

    cap.release()
    
    # Let user select ROI
    roi = cv2.selectROI("Select Object", frame, fromCenter=False, showCrosshair=True)
    cv2.destroyAllWindows()
    
    if roi == (0, 0, 0, 0):
        print("No object selected.")
        return None
    
    x, y, w, h = roi
    selected_region = frame[y:y+h, x:x+w]
    
    # Optional: save or process for tracking later
    cv2.imshow("Selected Object", selected_region)
    cv2.waitKey(500)
    cv2.destroyAllWindows()
    
    return roi, frame


# The save_roi_data and load_roi_data functions have been removed because
# this script now performs live zooming based on the current camera feed.


def zoom_to_object_live(robot):
    """Prompt the user to select an object and move the robot closer with live feedback.

    This function captures a frame from the camera, allows the user to
    select a region of interest (ROI) around the target object, and then
    continuously updates the tracking of that object while the robot moves
    forward along the Z-axis. The zooming continues until the object's
    apparent area in the camera frame reaches a specified proportion
    of the frame.

    Parameters
    ----------
    robot : URBasic.urScriptExt.UrScriptExt
        The robot interface used for motion commands.
    """
    # Open the camera
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Could not open camera.")
        return

    # Capture a single frame for ROI selection
    ret, frame = cap.read()
    if not ret:
        print("Failed to capture image for ROI selection.")
        cap.release()
        return

    # Ask user to select the object
    print("Select the target object to zoom in on.")
    roi = cv2.selectROI("Select Object", frame, fromCenter=False, showCrosshair=True)
    cv2.destroyAllWindows()
    if roi == (0, 0, 0, 0):
        print("No object selected.")
        cap.release()
        return
    x, y, w, h = [int(v) for v in roi]
    
    # Initialize tracker
    tracker = None
    # Try different tracker creation functions based on availability
    if hasattr(cv2, "TrackerCSRT_create"):
        tracker = cv2.TrackerCSRT_create()
    elif hasattr(cv2, "TrackerKCF_create"):
        tracker = cv2.TrackerKCF_create()
    else:
        # For OpenCV 4.x with legacy trackers
        try:
            tracker = cv2.TrackerCSRT_create()
        except Exception:
            try:
                tracker = cv2.legacy.TrackerCSRT_create()
            except Exception:
                try:
                    tracker = cv2.legacy.TrackerKCF_create()
                except Exception:
                    tracker = None
    if tracker is not None:
        # If a tracker is available (e.g. CSRT/KCF), use it for tracking
        tracker.init(frame, (x, y, w, h))

        # Compute initial frame size and area
        frame_size = (frame.shape[0], frame.shape[1])
        frame_area = frame_size[0] * frame_size[1]

        # Desired object-to-frame area ratio for stopping the zoom.  The
        # zooming loop will terminate once the object's area in the frame
        # reaches this proportion.  Adjust this value to control how
        # "close" the camera gets to the object.  Here we set it to 0.2
        # to stop zooming sooner.
        target_ratio = 0.2

        # Compute initial object ratio
        object_ratio = (w * h) / frame_area
        print(f"Initial object ratio: {object_ratio:.3f}")

        # Keep zooming until the object fills the desired proportion
        while object_ratio < target_ratio:
            # Read a new frame for tracking
            ret, new_frame = cap.read()
            if not ret:
                print("Camera feed lost during zoom.")
                break
            # Update the tracker with the new frame
            success, box = tracker.update(new_frame)
            if not success:
                print("Tracking lost during zoom.")
                break
            x, y, w, h = [int(v) for v in box]
            object_ratio = (w * h) / frame_area
            print(f"Object ratio: {object_ratio:.3f}, moving forward…")

            # Optionally display the tracking box for feedback
            cv2.rectangle(new_frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
            cv2.imshow("Zooming…", new_frame)
            cv2.waitKey(1)

            # Move the robot closer along the Z-axis
            pose = list(robot.get_actual_tcp_pose())
            pose[2] -= STEP_SIZE
            robot.movel(pose, a=ACCELERATION, v=VELOCITY)
            # Small delay to allow robot and camera update
            time.sleep(0.1)

        # Clean up
        cap.release()
        cv2.destroyAllWindows()
        print(f"Zoom complete. Final object ratio: {object_ratio:.3f}")
    else:
        # No modern tracker available. Use CamShift for tracking instead.
        print("No suitable built‑in tracker available. Falling back to CamShift for live zoom.")

        # Convert ROI to HSV and compute its histogram
        hsv_roi = cv2.cvtColor(frame[y:y+h, x:x+w], cv2.COLOR_BGR2HSV)
        # Create a mask to ignore very low saturation values (filter out extremes)
        mask = cv2.inRange(hsv_roi, (0, 30, 32), (180, 255, 255))
        roi_hist = cv2.calcHist([hsv_roi], [0], mask, [180], [0, 180])
        cv2.normalize(roi_hist, roi_hist, 0, 255, cv2.NORM_MINMAX)

        track_window = (x, y, w, h)

        # Compute initial frame size and area
        frame_size = (frame.shape[0], frame.shape[1])
        frame_area = frame_size[0] * frame_size[1]

        target_ratio = 0.06
        object_ratio = (w * h) / frame_area
        print(f"Initial object ratio: {object_ratio:.3f}")

        term_crit = (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 10, 1)

        while object_ratio < target_ratio:
            ret, new_frame = cap.read()
            if not ret:
                print("Camera feed lost during zoom.")
                break
            hsv = cv2.cvtColor(new_frame, cv2.COLOR_BGR2HSV)
            back_proj = cv2.calcBackProject([hsv], [0], roi_hist, [0, 180], 1)
            # Apply CamShift to get the new location
            ret_val, track_window = cv2.CamShift(back_proj, track_window, term_crit)
            x2, y2, w2, h2 = track_window
            object_ratio = (w2 * h2) / frame_area
            print(f"Object ratio: {object_ratio:.3f}, moving forward…")

            # Optionally display tracking box
            pts = cv2.boxPoints(ret_val)
            pts = pts.astype(int)
            cv2.polylines(new_frame, [pts], True, (0, 255, 0), 2)
            cv2.imshow("Zooming…", new_frame)
            cv2.waitKey(1)

            # Move robot along Z-axis
            pose = list(robot.get_actual_tcp_pose())
            pose[2] -= STEP_SIZE
            robot.movel(pose, a=ACCELERATION, v=VELOCITY)
            time.sleep(0.1)

        cap.release()
        cv2.destroyAllWindows()
        print(f"Zoom complete. Final object ratio: {object_ratio:.3f}")


def teleop_loop(robot):
    """The main teleoperation loop."""
    print("\nTeleoperation started.")
    print("Use R/F for Z translation and IJKL/UO for rotations. Press Q to quit.")

    fd = None
    if os.name != 'nt':
        try:
            fd = sys.stdin.fileno()
        except (AttributeError, io.UnsupportedOperation):
            fd = None

    with raw_mode(fd):
        while True:
            movement = input("Enter command: ").lower()
            if movement == 'q':
                print("Exiting teleoperation loop…")
                break

            pose = list(robot.get_actual_tcp_pose())
            moved = False

            # ---- Translation ----
            # Only allow Z-axis translation (R/F). X and Y movements are disabled.
            if movement == 'r':  # +Z
                pose[2] += STEP_SIZE
                moved = True
            elif movement == 'f':  # -Z
                pose[2] -= STEP_SIZE
                moved = True
            # X and Y translations (A/D/W/S) are intentionally ignored to
            # restrict motion to Z and rotations.

            # ---- Rotation ----
            elif movement == 'j':  # -Rx
                pose[3] -= STEP_ROT
                moved = True
            elif movement == 'l':  # +Rx
                pose[3] += STEP_ROT
                moved = True
            elif movement == 'i':  # +Ry
                pose[4] += STEP_ROT
                moved = True
            elif movement == 'k':  # -Ry
                pose[4] -= STEP_ROT
                moved = True
            elif movement == 'u':  # +Rz
                pose[5] += STEP_ROT
                moved = True
            elif movement == 'o':  # -Rz
                pose[5] -= STEP_ROT
                moved = True

            if moved:
                try:
                    robot.movel(pose, a=ACCELERATION, v=VELOCITY)
                    current_joints = list(robot.get_actual_joint_positions())
                    fk_position = Forwardkin_manip(current_joints, rob='ur5')
                    print(f"Current TCP Pose: {pose}")
                    print(f"Current TCP Position (FK): {fk_position}")
                except Exception as e:
                    print(f"Movement failed: {e}")
                    break


def main():
    """Main entry point."""
    try:
        robot = connect_robot()
        # Show initial TCP pose via forward kinematics
        initial_joints = list(robot.get_actual_joint_positions())
        fk_position = Forwardkin_manip(initial_joints, rob='ur5')
        print("Initial TCP Position (FK):", fk_position)
    except Exception as e:
        print(f"Failed to connect to robot: {e}")
        return

    # Prompt user to select object and perform live zoom
    zoom_to_object_live(robot)

    # Enter teleoperation loop
    try:
        teleop_loop(robot)
    except KeyboardInterrupt:
        print("Interrupted by user.")
    finally:
        robot.close()


if __name__ == '__main__':
    main()
