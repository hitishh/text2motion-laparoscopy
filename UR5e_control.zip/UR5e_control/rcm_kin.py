# rcm_kin.py
import math, numpy as np

# ---------- minimal rotation helpers ----------
def axis_angle_to_R(rx, ry, rz):
    a = (rx*rx+ry*ry+rz*rz)**0.5
    if a < 1e-9:
        return np.eye(3)
    ux,uy,uz = rx/a, ry/a, rz/a
    c,s = math.cos(a), math.sin(a); C = 1-c
    return np.array([
        [c+ux*ux*C, ux*uy*C-uz*s, ux*uz*C+uy*s],
        [uy*ux*C+uz*s, c+uy*uy*C, uy*uz*C-ux*s],
        [uz*ux*C-uy*s, uz*uy*C+ux*s, c+uz*uz*C]
    ])

def R_to_axis_angle(R):
    tr = np.trace(R)
    ang = math.acos(max(-1.0, min(1.0, (tr-1)/2)))
    if abs(ang) < 1e-9:
        return (0.0,0.0,0.0)
    rx = (R[2,1]-R[1,2])/(2*math.sin(ang))
    ry = (R[0,2]-R[2,0])/(2*math.sin(ang))
    rz = (R[1,0]-R[0,1])/(2*math.sin(ang))
    n = (rx*rx+ry*ry+rz*rz)**0.5
    rx,ry,rz = rx/n, ry/n, rz/n
    return (rx*ang, ry*ang, rz*ang)

# ---------- core RCM math (trocar pivot) ----------
def look_at_pose(TbP, pivot_b, targetP_mm, roll_deg=0.0, standoff_mm=250.0,
                 SAFE_MIN_STANDOFF_M=0.03, SAFE_MAX_STANDOFF_M=0.35):
    targetP = np.array([*targetP_mm, 1.0])/1000.0
    target_b = (TbP @ targetP)[:3]
    v = target_b - pivot_b
    v /= (np.linalg.norm(v) + 1e-9)

    up = np.array([0.0, 1.0, 0.0])
    x = np.cross(up, v)
    if np.linalg.norm(x) < 1e-6:
        up = np.array([1.0,0.0,0.0]); x = np.cross(up, v)
    x = x/np.linalg.norm(x)
    y = np.cross(v, x)
    R = np.column_stack([x, y, v])

    r = math.radians(roll_deg)
    Rz = np.array([[math.cos(r),-math.sin(r),0],[math.sin(r),math.cos(r),0],[0,0,1]])
    R = R @ Rz

    standoff_m = float(np.clip(standoff_mm/1000.0, SAFE_MIN_STANDOFF_M, SAFE_MAX_STANDOFF_M))
    pos_b = pivot_b - R[:,2] * standoff_m  # positive standoff = into patient

    rx,ry,rz = R_to_axis_angle(R)
    return [float(pos_b[0]), float(pos_b[1]), float(pos_b[2]), rx, ry, rz]

def zoom_pose(cur_pose, TbP, delta_mm,
              SAFE_MIN_STANDOFF_M=0.03, SAFE_MAX_STANDOFF_M=0.35):
    pivot_b = TbP[:3,3]
    R = axis_angle_to_R(cur_pose[3], cur_pose[4], cur_pose[5])
    z = R[:,2]
    # positive standoff into patient (negative dot)
    cur_standoff = -float(np.dot(np.array(cur_pose[:3]) - pivot_b, z))
    new_standoff = np.clip(cur_standoff - float(delta_mm)/1000.0,
                           SAFE_MIN_STANDOFF_M, SAFE_MAX_STANDOFF_M)
    pos_b = pivot_b - z * new_standoff
    return [float(pos_b[0]), float(pos_b[1]), float(pos_b[2]),
            cur_pose[3], cur_pose[4], cur_pose[5]]

def tilt_pose(cur_pose, TbP, d_rx_deg=0.0, d_ry_deg=0.0, SAFE_MAX_TILT_DEG=35):
    pivot_b = TbP[:3,3]
    R = axis_angle_to_R(cur_pose[3], cur_pose[4], cur_pose[5])
    z0 = TbP[:3,2]           # entry axis (+Z_P) expressed in base
    # keep current standoff
    standoff = -float(np.dot(np.array(cur_pose[:3]) - pivot_b, R[:,2]))
    # apply small local rotations
    ax = math.radians(d_rx_deg); ay = math.radians(d_ry_deg)
    Rx = np.array([[1,0,0],[0,math.cos(ax),-math.sin(ax)],[0,math.sin(ax),math.cos(ax)]])
    Ry = np.array([[math.cos(ay),0,math.sin(ay)],[0,1,0],[-math.sin(ay),0,math.cos(ay)]])
    R_new = R @ Rx @ Ry
    # clamp tilt vs entry axis
    z_new = R_new[:,2]
    ang = math.degrees(math.acos(np.clip(np.dot(z_new, z0)/(np.linalg.norm(z_new)*np.linalg.norm(z0)), -1.0, 1.0)))
    if ang > SAFE_MAX_TILT_DEG:
        s = SAFE_MAX_TILT_DEG / ang
        ax *= s; ay *= s
        Rx = np.array([[1,0,0],[0,math.cos(ax),-math.sin(ax)],[0,math.sin(ax),math.cos(ax)]])
        Ry = np.array([[math.cos(ay),0,math.sin(ay)],[0,1,0],[-math.sin(ay),0,math.cos(ay)]])
        R_new = R @ Rx @ Ry

    rx,ry,rz = R_to_axis_angle(R_new)
    pos_b = pivot_b - R_new[:,2] * standoff
    return [float(pos_b[0]), float(pos_b[1]), float(pos_b[2]), rx, ry, rz]

def standoff_mm(cur_pose, TbP):
    pivot_b = TbP[:3,3]
    R = axis_angle_to_R(cur_pose[3], cur_pose[4], cur_pose[5])
    z = R[:,2]
    return -float(np.dot(np.array(cur_pose[:3]) - pivot_b, z))*1000.0

# ---------- optional IK via your UR5eKinematics.py ----------
def solve_ik_if_available(target_pose_xyz_rxryrz, start_joint_rad):
    """
    If UR5eKinematics.Kinematic is available, compute joint targets for 'movej'.
    Otherwise return None to let caller use 'movel' in Cartesian.
    """
    try:
        from UR5eKinematics import Kinematic  # your file
        import math3d as m3d
        T = m3d.Transform()
        # Fill transform from axis-angle pose:
        x,y,z, rx,ry,rz = target_pose_xyz_rxryrz
        import numpy as np
        R = axis_angle_to_R(rx,ry,rz)
        T.orient = m3d.Orientation(R)
        T.pos = m3d.Vector(x,y,z)
        kin = Kinematic()
        q = kin.invKine(T, start_joint_rad)
        return list(map(float, q))
    except Exception:
        return None
